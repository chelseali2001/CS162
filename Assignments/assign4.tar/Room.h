#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class Room {
    private:
        Event* event;
        string event_type;
        vector<int> room_pos;

    public:
        Room();
        Room(string);
        ~Room();
        string get_event_type(vector<int>, int, int, string);
        vector<int> get_room_pos();
        string get_event();
        void set_event_type(string);
        void set_room_pos(int, int);
        void room_action(bool);
};