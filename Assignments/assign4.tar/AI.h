#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class AI : public Game {
    private:
        vector<vector<int>> safe_rooms;
        vector<vector<int>> move_options;
        bool ai_used;
        
    public:
        AI(int, string);
        bool get_ai_used();
        void set_ai_used(bool);
        void find_dead_end();
        bool find_event(string);
        void ai_move(vector<float>);
        void pick_direction();
        void possible_directions();
        void decide_action();
        void play_AI();
};