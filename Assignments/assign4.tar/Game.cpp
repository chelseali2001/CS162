#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "./Event.h"
#include "./Wumpus.h"
#include "./Bats.h"
#include "./Pit.h"
#include "./Gold.h"
#include "./Room.h"
#include "./Game.h"
#include "./AI.h"
#include "./Other.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Game
 ** Description: Parameterized constructor for the Game class.
 ** Parameters: int game_dimension, string mode
 ** Pre-Conditions: 1 int and 1 string.
 ** Post-Conditions: Initializes the member variables in the Game class.
**************************************************************************************************************/
Game::Game(int game_dimension, string mode) {
    dimension = game_dimension;
    debug_mode = mode;
    arrows = 3;
    got_gold = false;
    wumpus_dead = false;
    game_board.assign(dimension, vector<Room>(dimension));
    
    string v[7] = {"P", "P", "B", "B", "W", "G", "E"};

    for (int x = 0; x < 7; x++) {
        vector<int> key = generate_pos();
        start_events.push_back(key);
        game_board[key[0]][key[1]] = Room(v[x]);
    }

    for (int x = 0; x < dimension; x++)
        for (int i = 0; i < dimension; i++) 
            game_board[x][i].set_room_pos(x, i);

    player_loc = start_events[6];
}

/**************************************************************************************************************
 ** Function: get_arrows
 ** Description: Gives you the value of the arrows variable in the Game class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the arrows variable.
**************************************************************************************************************/
int Game::get_arrows() {
    return arrows;
}

/**************************************************************************************************************
 ** Function: generate_pos
 ** Description: Generates random positions.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Random positions are generated for the events.
**************************************************************************************************************/
vector<int> Game::generate_pos() {
    bool valid = false;
    vector<int> key = {rand() % dimension, rand() % dimension};
    
    srand(time(NULL));
    
    while (!valid) {
        int total = 0;
        
        for (int x = 0; x < start_events.size(); x++)
            if (start_events[x] == key)
                total++;
        
        if (total == 0)
            valid = true;
        else if (total > 0)
            key = {rand() % dimension, rand() % dimension};
    }
    
     return key;    
}

/**************************************************************************************************************
 ** Function: print_board
 ** Description: Prints out the game.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Prints out the game.
**************************************************************************************************************/
void Game::print_board() {
    cout << "\n" <<endl;

    for (int x = 0; x < dimension; x++) {
        for (int i = 0; i < dimension; i++)
            cout << "+---";
        
        cout << "+" <<endl;

        for (int i = 0; i < dimension; i++)
            cout << "|   ";
        
        cout << "|" <<endl;

        for (int i = 0; i < dimension; i++)
            cout << "| " << game_board[x][i].get_event_type(player_loc, x, i, debug_mode) << " ";
        
        cout << "|" <<endl; 

        for (int i = 0; i < dimension; i++)
            cout << "|   ";
        
        cout << "|" <<endl;
    }

    for (int i = 0; i < dimension; i++)
        cout << "+---";
    
    cout << "+" <<endl;
}

/**************************************************************************************************************
 ** Function: check_boards
 ** Description: Tells you if the direction the player wants to move will be in bounds.
 ** Parameters: string direction
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: Returns a bool indicating whether or not direction the player wants to move is in bounds.
**************************************************************************************************************/
bool Game::check_bounds(string direction) {
    if ((direction == "w" && (player_loc[0] - 1 >= 0)) ||
        (direction == "a" && (player_loc[1] - 1 >= 0)) ||
        (direction == "s" && (player_loc[0] + 1 < dimension)) ||
        (direction == "d" && (player_loc[1] + 1 < dimension)) ||
        direction == " ")
        return true;
    
    return false;
}

/**************************************************************************************************************
 ** Function: change_pos
 ** Description: Changes the location of the player.
 ** Parameters: string direction
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: Changes the player's position.
**************************************************************************************************************/
void Game::change_pos(string direction) {
    first_move = false;

    if (direction == " ")
        shoot_arrow();
    else if (direction == "w")
        player_loc[0] -= 1;
    else if (direction == "a")
        player_loc[1] -= 1;
    else if (direction == "s")
        player_loc[0] += 1;
    else if (direction == "d")
        player_loc[1] += 1;
    
    if (direction == " ")
        cin.ignore();
}

/**************************************************************************************************************
 ** Function: move
 ** Description: Player decides if they want to shoot an arrow or move to another room.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Player enters space to shoot an arrow or the 'WASD' characters to move.
**************************************************************************************************************/
void Game::move() {
    bool in_bounds = false, valid = false;
    string direction;
    
    if (first_move)
        cin.ignore();
    
    while (!valid) {
        cout << "Enter space to shoot an arrow (you have " << arrows << " arrow(s)), 'w' to go north, 'a' to go west, 's' to go south, or 'd' to go east.";
        
        direction = getch();
        in_bounds = check_bounds(direction);

        if (direction == " " && arrows == 0)
            cout << "\nYou are out of arrows. Try again.\n" <<endl;
        else if (direction != " " && direction != "w" && direction != "a" && direction != "s" && direction != "d")
            cout << "\nError: Invalid input. Try again.\n" <<endl;
        else if (!in_bounds)
            cout << "\nError: You'll go out of bounds. Try again.\n" <<endl;
        else
            valid = true;
    }

    change_pos(direction);
}

/**************************************************************************************************************
 ** Function: kill_wumpus
 ** Description: Removes the Wumpus from the game.
 ** Parameters: int x_pos, int y_pos
 ** Pre-Conditions: 2 ints.
 ** Post-Conditions: Removes the Wumpus from the game.
**************************************************************************************************************/
void Game::kill_wumpus(int x_pos, int y_pos) {
    cout << "You just killed the Wumpus!" <<endl;
    game_board[x_pos][y_pos].set_event_type(" ");
    wumpus_dead = true;
}

/**************************************************************************************************************
 ** Function: wake_wumpus
 ** Description: 75% chance the Wumpus will wake up.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: If the Wumpus wakes, it'll move to a new room.
**************************************************************************************************************/
void Game::wake_wumpus() {
    vector<int> wumpus_loc;

    for (int x = 0; x < dimension; x++)
        for (int i = 0; i < dimension; i++)
            if (game_board[x][i].get_event() == "W")
                wumpus_loc = game_board[x][i].get_room_pos();

    int should_wake = rand() % 4;

    if (should_wake < 3) {
        cout << "You woke up the wumpus with your arrow and it has moved to a different room." <<endl;

        vector<int> key = {rand() % dimension, rand() % dimension};

        while (game_board[key[0]][key[1]].get_event() != " " || game_board[key[0]][key[1]].get_room_pos() == player_loc)
            key = {rand() % dimension, rand() % dimension};
        
        cout << game_board[key[0]][key[1]].get_event() <<endl;
        game_board[wumpus_loc[0]][wumpus_loc[1]].set_event_type(" ");
        game_board[key[0]][key[1]].set_event_type("W");
    }
}

/**************************************************************************************************************
 ** Function: shoot_north
 ** Description: The arrow will shoot north.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The arrow will shoot north until it hits a wall or goes through 3 rooms.
**************************************************************************************************************/
void Game::shot_north() {
    int rooms = 0;

    for (int x = player_loc[0] - 1; x >= 0; x--) {
        if (game_board[x][player_loc[1]].get_event() == "W") 
            kill_wumpus(x, player_loc[1]);                

        rooms++;

        if (rooms == 3)
            break;
    }
}

/**************************************************************************************************************
 ** Function: shoot_west
 ** Description: The arrow will shoot west.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The arrow will shoot west until it hits a wall or goes through 3 rooms.
**************************************************************************************************************/
void Game::shot_west() {
    int rooms = 0;

    for (int x = player_loc[1] - 1; x >= 0; x--) {
        if (game_board[player_loc[0]][x].get_event() == "W")
            kill_wumpus(player_loc[0], x);

        rooms++;

        if (rooms == 3)
            break;
    }
}

/**************************************************************************************************************
 ** Function: shoot_south
 ** Description: The arrow will shoot south.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The arrow will shoot south until it hits a wall or goes through 3 rooms.
**************************************************************************************************************/
void Game::shot_south() {
    int rooms = 0;

    for (int x = player_loc[0] + 1; x < dimension; x++) {
        if (game_board[x][player_loc[1]].get_event() == "W")
            kill_wumpus(x, player_loc[1]);

        rooms++;

        if (rooms == 3)
            break;
    }
}

/**************************************************************************************************************
 ** Function: shoot_east
 ** Description: The arrow will shoot east.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The arrow will shoot east until it hits a wall or goes through 3 rooms.
**************************************************************************************************************/
void Game::shot_east() {
    int rooms = 0;

    for (int x = player_loc[1] + 1; x < dimension; x++) {
        if (game_board[player_loc[0]][x].get_event() == "W")
            kill_wumpus(player_loc[0], x);

        rooms++;

        if (rooms == 3)
            break;  
    }  
}

/**************************************************************************************************************
 ** Function: arrow_shot
 ** Description: The arrow will shoot in the direction the player chose.
 ** Parameters: string direction
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: The arrow will shoot in the direction the player chose.
**************************************************************************************************************/
void Game::arrow_shot(string direction) {
    int rooms = 0;

    if (direction == "w")
        shot_north();
    else if (direction == "a")
        shot_west();
    else if (direction == "s")
        shot_south();
    else if (direction == "d")
        shot_east();

    if (!wumpus_dead) {
        wake_wumpus();
        cout << "You didn't hit anything." <<endl;
    }

    arrows--;
}

/**************************************************************************************************************
 ** Function: shoot_arrow
 ** Description: The player picks the direction they want to shoot an arrow.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The arrow will shoot in the direction the player chooeses.
**************************************************************************************************************/
void Game::shoot_arrow() {
    string shoot = "";
    
    while (shoot != "w" && shoot != "a" && shoot != "s" && shoot != "d") {
        cout << "\nEnter 'w' to shoot north, 'a' to shoot west, 's' to shoot south, or 'd' to shoot east: ";
        cin >> shoot;
    
        if (shoot != "w" && shoot != "a" && shoot != "s" && shoot != "d")
            cout << "\nError: invalid input. Try again.\n" <<endl;
    }
    
    arrow_shot(shoot);
}

/**************************************************************************************************************
 ** Function: check_surroundings
 ** Description: Checks the events in the adjacent rooms.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Calls the precept or encounter function depending on the events in the adjacent rooms.
**************************************************************************************************************/
void Game::check_surroundings() {
    if (check_bounds("w"))
        game_board[player_loc[0] - 1][player_loc[1]].room_action(true);
    
    if (check_bounds("a"))
        game_board[player_loc[0]][player_loc[1] - 1].room_action(true);
    
    if (check_bounds("s"))
        game_board[player_loc[0] + 1][player_loc[1]].room_action(true);
    
    if (check_bounds("d"))
        game_board[player_loc[0]][player_loc[1] + 1].room_action(true);
}

/**************************************************************************************************************
 ** Function: check_current_room
 ** Description: Checks the event in the current room.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns an int indicating the event that took place in the room the player is in.
**************************************************************************************************************/
int Game::check_current_room() {
    game_board[player_loc[0]][player_loc[1]].room_action(false);
    
    if (game_board[player_loc[0]][player_loc[1]].get_event() == "W" ||
        game_board[player_loc[0]][player_loc[1]].get_event() == "P") {
        cout << "You lost the game :(" <<endl;
    } else if (game_board[player_loc[0]][player_loc[1]].get_event() == "E" && got_gold) {
        cout << "\nYou won the game! :)" <<endl;
    } else {
        if (game_board[player_loc[0]][player_loc[1]].get_event() == "G") {
            game_board[player_loc[0]][player_loc[1]].set_event_type(" ");
            got_gold = true;
        } else if (game_board[player_loc[0]][player_loc[1]].get_event() == "B") {
            vector<int> key = {rand() % dimension, rand() % dimension};

            while (player_loc == key)
                key = {rand() % dimension, rand() % dimension};
            
            prev_pos = key;
            player_loc = key;
            
            return 1;
        }

        return 2;
    }
    
    return 3;
}

/**************************************************************************************************************
 ** Function: win
 ** Description: Checks if the player won.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns a bool indicating whether or not the user won the game.
**************************************************************************************************************/
bool Game::win() {
    if (game_board[player_loc[0]][player_loc[1]].get_event() == "W" ||
        game_board[player_loc[0]][player_loc[1]].get_event() == "P")
        return false;
    
    return true;
}

/**************************************************************************************************************
 ** Function: randomize_events()
 ** Description: Randomizes the events.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The events are randomized.
**************************************************************************************************************/
void Game::randomize_events() {
    for (int x = 0; x < 7; x++) {
        vector<int> key = generate_pos();
        start_events[x] = key;
    }
}

/**************************************************************************************************************
 ** Function: reset
 ** Description: Resets the game.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The game will reset.
**************************************************************************************************************/
void Game::reset() {
    string v[7] = {"P", "P", "B", "B", "W", "G", "E"};

    for (int x = 0; x < dimension; x++)
        for (int i = 0; i < dimension; i++)
            game_board[x][i].set_event_type(" ");

    for (int x = 0; x < 7; x++)
        game_board[start_events[x][0]][start_events[x][1]].set_event_type(v[x]);
    
    player_loc = start_events[6];
    prev_pos = player_loc;
    arrows = 3;
    got_gold = false;
    wumpus_dead = false;
    first_move = true;
}