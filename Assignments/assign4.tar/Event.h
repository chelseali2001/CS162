#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class Event {
    public:
        virtual void percept() = 0;
        virtual void encounter() = 0;
};