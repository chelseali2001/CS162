#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class Game {
    protected:
        int dimension;
        vector<vector<Room>> game_board;
        string debug_mode;
        int arrows;
        vector<vector<int>> start_events;
        vector<int> player_loc;
        bool got_gold;
        bool wumpus_dead;
        vector<int> prev_pos;
        bool first_move;

    public:
        Game(int, string);
        int get_arrows();
        vector<int> generate_pos();
        void print_board();
        bool check_bounds(string);
        void change_pos(string);
        void move();
        void kill_wumpus(int, int);
        void wake_wumpus();
        void shot_north();
        void shot_west();
        void shot_south();
        void shot_east();
        void arrow_shot(string);
        void shoot_arrow();
        void check_surroundings();
        int check_current_room();
        bool win();
        void randomize_events();
        void reset();
};