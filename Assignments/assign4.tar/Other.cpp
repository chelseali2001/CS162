#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "./Event.h"
#include "./Wumpus.h"
#include "./Bats.h"
#include "./Pit.h"
#include "./Gold.h"
#include "./Room.h"
#include "./Game.h"
#include "./AI.h"
#include "./Other.h"

using namespace std;

/**************************************************************************************************************
 ** Function: getch
 ** Description: Allows the user to enter a char without entering space.
 ** Parameters: void
 ** Pre-Conditions: 1 void.
 ** Post-Conditions: The user can enter a char without entering space.
**************************************************************************************************************/
int getch(void) {
    int x;
    struct termios old_val, new_val;
    
    tcgetattr(STDIN_FILENO, &old_val);
    
    new_val = old_val;
    new_val.c_lflag &= ~(ICANON | ECHO);
    
    tcsetattr(STDIN_FILENO, TCSANOW, &new_val);
    
    x = getchar();
    
    tcsetattr(STDIN_FILENO, TCSANOW, &old_val);
    
    return x;
}

/**************************************************************************************************************
 ** Function: is_int
 ** Description: Determines if the input is an integer.
 ** Parameters: string n
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: Returns a bool indicating if the input is an int.
**************************************************************************************************************/
bool is_int(string n) {
    for (int x = 0; x < n.size(); x++)
        if (n[x] < '0' || n[x] > '9')
            return false;
    
    return true;
}

/**************************************************************************************************************
 ** Function: check_comm_line
 ** Description: Checks if the command line inputs are valid.
 ** Parameters: int argc, char* argv[]
 ** Pre-Conditions: 1 int and 1 char**.
 ** Post-Conditions: Returns a bool indicating if the command line inputs are valid.
**************************************************************************************************************/
bool check_comm_line(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Two command line inputs are needed." <<endl;
    } else if (argc > 3) {
        cout << "There are too many command line inputs." <<endl;
    } else if (argc == 3) {
        if ((strcmp(argv[2], "false") == 0 || strcmp(argv[2], "true") == 0) && (atoi(argv[1]) >= 4))
            return true;
            
        if (atoi(argv[1]) < 4)
            cout << "Enter at least 4 rooms." <<endl;
        
        if (strcmp(argv[2], "false") != 0 && strcmp(argv[2], "true") != 0)
            cout << "A boolean is needed." <<endl;
    }

    return false;
}

/**************************************************************************************************************
 ** Function: use_AI
 ** Description: User picks if they want to use AI or play the game themselves.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns a bool to indicate how the user wants to play the game.
**************************************************************************************************************/
bool use_AI() {
    int choice = 0;
    
    while (choice != 1 && choice != 2) {
        cout << "\nEnter 1 to use AI or 2 if you want to play the game yourself: ";
        cin >> choice;
        
        if (choice != 1 && choice != 2) {
            cin.clear();
            cin.ignore(256, '\n');
            cout << "Error: invalid input. Try again." <<endl;
        }
    }
    
    if (choice == 1)
        return true;
    else if (choice == 2)
        return false;
}

/**************************************************************************************************************
 ** Function: play_game
 ** Description: Sets up the game based on how the user wants to play.
 ** Parameters: AI &ai
 ** Pre-Conditions: 1 AI&.
 ** Post-Conditions: The game will be played based on how the user wants to play.
**************************************************************************************************************/
void play_game(AI &ai) {
    int game_room = 2;

    if (!use_AI()) {
        ai.set_ai_used(false);
        
        while (game_room != 3) {
            ai.print_board();
            ai.check_surroundings();
            ai.move();
            
            game_room = ai.check_current_room();
      
            while(game_room == 1)
                game_room = ai.check_current_room();
        }
    } else {
        ai.set_ai_used(true);
        ai.play_AI();
    }
}

/**************************************************************************************************************
 ** Function: play_again
 ** Description: User decides if they want to play again with the same or different cave or to exit.
 ** Parameters: AI &ai
 ** Pre-Conditions: 1 AI&.
 ** Post-Conditions: Returns a string indicating if the user wants to play again or exit.
**************************************************************************************************************/
string play_again(AI &ai) {
    string choice = "";
    
    if (ai.get_ai_used())
        cin.ignore();

    while (choice != "1" && choice != "2" && choice != "3") {
        cout << "\nEnter 1 to start over with the same cave, 2 to start over with a new cave, or 3 to exit: ";
        getline(cin, choice);

        if (choice != "1" && choice != "2" && choice != "3")
            cout << "Error: invalid input. Try again." <<endl;
    }
    
    if (choice == "2") 
        choice = change_cave(ai);

    return choice;
}


/**************************************************************************************************************
 ** Function: change_cave
 ** Description: User decides if they want to randomize the events or make a whole new cave.
 ** Parameters: AI &ai
 ** Pre-Conditions: 1 AI&.
 ** Post-Conditions: Returns a string indicating how they want to change the cave.
**************************************************************************************************************/
string change_cave(AI &ai) {
    string choice = "";
    
    while (choice != "1" && choice != "2") {
        cout << "\nEnter 1 use the same layout but randomize the events or enter 2 to make a whole new cave: ";
        getline(cin, choice);
        
        if (choice != "1" && choice != "2")
            cout << "Error: invalid input. Try again." <<endl;
    }
    
    if (choice == "1")
        ai.randomize_events();
  
    return choice;
}

/**************************************************************************************************************
 ** Function: new_values
 ** Description: User enters the new values for a new cave.
 ** Parameters: int &game_dimension, string &debug
 ** Pre-Conditions: 1 int& and 1 string&.
 ** Post-Conditions: The user will enter the new game dimension and the mode they want.
**************************************************************************************************************/
void new_values(int &game_dimension, string &debug) {
    int new_dimension = 0;
    string new_debug = "";

    while (new_dimension < 4) {
        cout << "\nEnter the new game dimension: ";
        cin >> new_dimension;

        if (new_dimension < 4) {
            cin.clear();
            cin.ignore(256, '\n');
            cout << "Error: invalid input. Try again." <<endl;
        }
    }

    cin.ignore();

    while (new_debug != "false" && new_debug != "true") {
        cout << "Enter the mode you want: ";
        getline(cin, new_debug);

        if (new_debug != "false" && new_debug != "true")
            cout << "Error: invalid input. Try again.\n" <<endl;
    }

    game_dimension = new_dimension;
    debug = new_debug;
}