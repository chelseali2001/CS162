#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "./Event.h"
#include "./Wumpus.h"
#include "./Bats.h"
#include "./Pit.h"
#include "./Gold.h"
#include "./Room.h"
#include "./Game.h"
#include "./AI.h"
#include "./Other.h"

using namespace std;

/**************************************************************************************************************
 ** Function: AI
 ** Description: Parameterized constructor for the AI class.
 ** Parameters: int dimension, string debug
 ** Pre-Conditions: 1 int and 1 string.
 ** Post-Conditions: Initializes the member variables in the AI class.
**************************************************************************************************************/
AI::AI(int dimension, string debug) : Game(dimension, debug) {
    ai_used = true;
    safe_rooms.assign(dimension, vector<int>(dimension));
    move_options.assign(4, vector<int>(2));
    prev_pos = player_loc;
    first_move = true;
    
    for (int x = 0; x < dimension; x++)
        for (int i = 0; i < dimension; i++)
            if (game_board[x][i].get_event() == "P")
                safe_rooms[x][i] = 1;
            else
                safe_rooms[x][i] = 0;
    
    for (int x = 0; x < 4; x++)
        move_options[x] = {-1, -1};
        
    find_dead_end();
}

/**************************************************************************************************************
 ** Function: get_ai_used
 ** Description: Gives you the value of the ai_used variable in the AI class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the ai_used variable.
**************************************************************************************************************/
bool AI::get_ai_used() {
    return ai_used;
}

/**************************************************************************************************************
 ** Function: set_ai_used
 ** Description: Changes the value of the ai_used variable in the AI class.
 ** Parameters: bool n
 ** Pre-Conditions: 1 bool.
 ** Post-Conditions: The value of the ai_used variable is changed to a new value.
**************************************************************************************************************/
void AI::set_ai_used(bool n) {
    ai_used = n;
}

/**************************************************************************************************************
 ** Function: find_dead_end
 ** Description: Finds any dead ends in the game.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Finds any room where there's 2 pits nearby.
**************************************************************************************************************/
void AI::find_dead_end() {
    for (int x = 0; x < dimension; x++)
        for (int i = 0; i < dimension; i++) {
            int total_pits = 0;
            
            if (x - 1 > 0)
                if (safe_rooms[x - 1][i] == 1)
                    total_pits++;
            else if (i - 1 > 0)
                if (safe_rooms[x][i - 1] == 1)
                    total_pits++;
            else if (x + 1 < dimension)
                if (safe_rooms[x + 1][i] == 1)
                    total_pits++;
            else if (i + 1 < dimension)
                if (safe_rooms[x][i + 1] == 1)
                    total_pits++;
            
            if (total_pits == 2)
                safe_rooms[x][i] = 1;
        }
}

/**************************************************************************************************************
 ** Function: find_event
 ** Description: Finds an event in the nearby rooms.
 ** Parameters: string n
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: Returns a bool indicating if a specfic event is nearby.
**************************************************************************************************************/
bool AI::find_event(string n) {
    if (check_bounds("w"))
        if (game_board[player_loc[0] - 1][player_loc[1]].get_event() == n)
            return true;
    
    if (check_bounds("a"))
        if (game_board[player_loc[0]][player_loc[1] - 1].get_event() == n)
            return true;
    
    if (check_bounds("s"))
        if (game_board[player_loc[0] + 1][player_loc[1]].get_event() == n)
            return true;
    
    if (check_bounds("d"))
        if (game_board[player_loc[0]][player_loc[1] + 1].get_event() == n)
            return true;
    
    return false;
}

/**************************************************************************************************************
 ** Function: ai_move
 ** Description: Player moves to a new location.
 ** Parameters: vector<float> displacement
 ** Pre-Conditions: 1 vector<float>.
 ** Post-Conditions: The player is moved to the room that's closes to the gold or exit.
**************************************************************************************************************/
void AI::ai_move(vector<float> displacement) {
    int min = 0;
    
    for (int x = 0; x < 4; x++)
        if (displacement[x] != 0) {
            min = x;
            break;
        }
    
    for (int x = min; x < 4; x++)
        if (displacement[x] < displacement[min] && displacement[x] != 0)
            min = x;
    
    prev_pos = player_loc;
    player_loc = move_options[min];
}

/**************************************************************************************************************
 ** Function: pick_direction
 ** Description: Calculates the displacement of each room from the gold or exit.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The displacement of each room from the gold or exit are calculated.
**************************************************************************************************************/
void AI::pick_direction() {
    vector<float> displacement;
    vector<int> v = {-1, -1};
    int needed_event = 0;
    int total_paths = 0;
    
    if (got_gold)
        needed_event = 6;
    else
        needed_event = 5;
    
    for (int x = 0; x < 4; x++)
        if (move_options[x] == v) {
            displacement.push_back(0);
        } else if (safe_rooms[move_options[x][0]][move_options[x][1]] == 0) {
            displacement.push_back(sqrt(pow(start_events[needed_event][0] - move_options[x][0], 2) + pow(start_events[needed_event][1] - move_options[x][1], 2)));
            total_paths++;
        }
    
    if (total_paths == 0)
        player_loc = start_events[0];
    else
        ai_move(displacement);
}

/**************************************************************************************************************
 ** Function: possible_directions
 ** Description: Finds the possible rooms the player can go to without dying or going into a wall.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The possible rooms the player can go to will be found.
**************************************************************************************************************/
void AI::possible_directions() {
    vector<int> v = {-1, -1};
    
    for (int x = 0; x < 4; x++)
        move_options[x] = v;
        
    if (check_bounds("w"))
        if (safe_rooms[player_loc[0] - 1][player_loc[1]] == 0 && game_board[player_loc[0] - 1][player_loc[1]].get_room_pos() != prev_pos)
            move_options[0] = game_board[player_loc[0] - 1][player_loc[1]].get_room_pos();
            
    if (check_bounds("a"))
        if (safe_rooms[player_loc[0]][player_loc[1] - 1] == 0 && game_board[player_loc[0]][player_loc[1] - 1].get_room_pos() != prev_pos)
            move_options[1] = game_board[player_loc[0]][player_loc[1] - 1].get_room_pos();
    
    if (check_bounds("s"))
        if (safe_rooms[player_loc[0] + 1][player_loc[1]] == 0 && game_board[player_loc[0] + 1][player_loc[1]].get_room_pos() != prev_pos)
            move_options[2] = game_board[player_loc[0] + 1][player_loc[1]].get_room_pos();
                
    if (check_bounds("d"))
        if (safe_rooms[player_loc[0]][player_loc[1] + 1] == 0 && game_board[player_loc[0]][player_loc[1] + 1].get_room_pos() != prev_pos)
            move_options[3] = game_board[player_loc[0]][player_loc[1] + 1].get_room_pos();

    pick_direction();
}

/**************************************************************************************************************
 ** Function: decide_action
 ** Description: The AI will decide to shoot an arrow or move to another room.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The AI will decide to shoot an arrow or move to another room.
**************************************************************************************************************/
void AI::decide_action() {
    if (find_event("W")) {
        game_board[start_events[4][0]][start_events[4][1]].set_event_type(" ");
        cout << "You just killed the Wumpus!" <<endl;
        arrows--;
    }

    if (find_event("E") && got_gold) {
        player_loc = start_events[6];
    } else if (find_event("G")) {
        prev_pos = start_events[5];
        player_loc = start_events[5];
    } else {
        possible_directions();
    }
}

/**************************************************************************************************************
 ** Function: play_AI
 ** Description: Runs the AI.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The game will be played using AI.
**************************************************************************************************************/
void AI::play_AI() {
    int game_room = 2;
    
    while (game_room != 3) {
        print_board();
        check_surroundings();
        
        cout << "You have " << arrows << " arrow(s) left." <<endl;
        
        decide_action();
        
        game_room = check_current_room();
  
        while(game_room == 1)
            game_room = check_current_room();
    }
}