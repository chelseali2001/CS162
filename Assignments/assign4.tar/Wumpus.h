#include <iostream>
#include <string> 
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class Wumpus : public Event {
    public:
        void percept() { cout << "You smell a terrible stench." <<endl; }
        void encounter() { cout << "\nYou encountered the Wumpus." <<endl; }
};