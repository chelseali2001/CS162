#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "./Event.h"
#include "./Wumpus.h"
#include "./Bats.h"
#include "./Pit.h"
#include "./Gold.h"
#include "./Room.h"
#include "./Game.h"
#include "./AI.h"
#include "./Other.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Room
 ** Description: Default constructor for the Room class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Initializes the member variables in the Room class.
**************************************************************************************************************/
Room::Room() {
    event_type = " ";
}

/**************************************************************************************************************
 ** Function: Room
 ** Description: Parameterized constructor for the Zoo class.
 ** Parameters: string type
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: Initializes the member variables in the Room class.
**************************************************************************************************************/
Room::Room(string type) {
    event_type = type;
}

/**************************************************************************************************************
 ** Function: ~Room
 ** Description: Destructor for the Room class.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Deletes all dynamically allocated memory in the Room class.
**************************************************************************************************************/
Room::~Room() {
    event = NULL; 
    delete event;
}

/**************************************************************************************************************
 ** Function: get_event_type
 ** Description: Gives you the value of the event_type variable in the Room class.
 ** Parameters: vector<int> player_loc, int x_pos, int y_pos, string debug_mode
 ** Pre-Conditions: 1 vector<int>, 2 ints, and 1 string.
 ** Post-Conditions: Returns the value of the event_type variable depending on the user location and mode.
**************************************************************************************************************/
string Room::get_event_type(vector<int> player_loc, int x_pos, int y_pos, string debug_mode) {
    if (player_loc[0] == x_pos && player_loc[1] == y_pos)
        return "*";
    else if (debug_mode == "false")
        return " ";
    else if (debug_mode == "true")
        return event_type;
}

/**************************************************************************************************************
 ** Function: get_room_pos
 ** Description: Gives you the value of the room_pos variable in the Room class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the room_pos variable.
**************************************************************************************************************/
vector<int> Room::get_room_pos() {
    return room_pos;
}

/**************************************************************************************************************
 ** Function: get_event
 ** Description: Gives you the value of the event_type variable in the Room class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the event_type variable.
**************************************************************************************************************/
string Room::get_event() {
    return event_type;
}

/**************************************************************************************************************
 ** Function: set_event_type
 ** Description: Changes the value of the event_type variable in the Room class.
 ** Parameters: string n
 ** Pre-Conditions: 1 string.
 ** Post-Conditions: The value of the event_type variable is changed to a new value.
**************************************************************************************************************/
void Room::set_event_type(string n) {
    event_type = n;
}

/**************************************************************************************************************
 ** Function: set_room_pos
 ** Description: Changes the value of the room_pos variable in the Room class.
 ** Parameters: int x, int y
 ** Pre-Conditions: 2 ints.
 ** Post-Conditions: The value of the room_pos variable is changed to a new value.
**************************************************************************************************************/
void Room::set_room_pos(int x, int y) {
    room_pos.push_back(x);
    room_pos.push_back(y);
}

/**************************************************************************************************************
 ** Function: room_action
 ** Description: An action is taken if the player is close to or is in a room that has an event.
 ** Parameters: bool percept
 ** Pre-Conditions: 1 bool
 ** Post-Conditions: The percept or encounter functions are called depending on the events around the player.
**************************************************************************************************************/
void Room::room_action(bool percept) {
    Wumpus wumpus;
    Bats bats;
    Pit pit;
    Gold gold;
    
    if (event_type == "W") 
        event = &wumpus;
    else if (event_type == "B")
        event = &bats;
    else if (event_type == "P")
        event = &pit;
    else if (event_type == "G")
        event = &gold;

    if (event_type != " " && event_type != "E")
        if (percept)
            event->percept();
        else 
            event->encounter();        
}