#include <iostream>
#include <string> 
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class Bats : public Event {
    public:
        void percept() { cout << "You hear wings flapping." <<endl; }
        void encounter() { cout << "\nYou encountered a room full of bats and they moved you to a new room." <<endl; }
};