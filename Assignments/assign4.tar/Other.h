#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

int getch(void);
bool is_int(string);
bool check_comm_line(int, char**);
bool use_AI();
void play_game(AI&);
string play_again(AI&);
string change_cave(AI&);
void new_values(int&, string&);