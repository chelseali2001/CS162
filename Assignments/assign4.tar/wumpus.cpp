#include <iostream>
#include <string> 
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "./Event.h"
#include "./Wumpus.h"
#include "./Bats.h"
#include "./Pit.h"
#include "./Gold.h"
#include "./Room.h"
#include "./Game.h"
#include "./AI.h"
#include "./Other.h"

using namespace std;

/******************************************************
** Program: wumpus.cpp
** Author: Chelsea Li
** Date: 5/24/20
** Description: Hunt the Wumpus!
** Input: 1 int and 1 bool
** Output: Hunt the Wumpus game.
******************************************************/
int main(int argc, char* argv[]) {
    if (check_comm_line(argc, argv)) {
        string new_game = "";
        int game_dimension = atoi(argv[1]);
        string debug = argv[2];
        AI ai(game_dimension, debug);

        while (new_game != "3") {
            play_game(ai);

            if (!ai.win())
                new_game = play_again(ai);
            else
                new_game = "3";

            if (new_game == "1") {
                ai.reset();
            } else if (new_game == "2") {
                new_values(game_dimension, debug);
                ai = AI(game_dimension, debug);
            }
        }
    } 

    return 0;
}