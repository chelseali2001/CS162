#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstring>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>

using namespace std;

class Gold : public Event {
    public:
        void percept() { cout << "You see a glimmer nearby." <<endl; }
        void encounter() { cout << "\nYou found the gold!" <<endl; }

};