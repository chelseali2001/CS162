#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

class Card {
    private:
        int rank;  // Should be in the range 0-12.
        int suit;  // Should be in the range 0-3.
    public:
        Card(){};
        Card(int, int);
        int get_rank();
        int get_suit();
        void set_suit(int);
        string convert_rank(int);
        string convert_suit(int);
};