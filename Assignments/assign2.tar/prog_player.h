#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

class Player {
    private:
        Hand hand;
        string name;
    public:
        Player(){};
        Player(string, Deck&);
        Hand get_hand();
        string get_name();
        void set_hand(int, int, Deck&);
        void print_hand();
};