#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "./prog_card.h"
#include "./prog_deck.h"
#include "./prog_hand.h"
#include "./prog_player.h"
#include "./prog_game.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Game
 ** Description: Initializes objects of Game class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Initializes the cards and players variables in the Game class.
**************************************************************************************************************/
Game::Game() {
    players[0] = Player("Player", cards);
    players[1] = Player("Computer", cards);

    cards.set_top_card(cards.get_card(14));
    cards.reduce_n_cards_deck();
}

/**************************************************************************************************************
 ** Function: ~Game
 ** Description: Deletes objects of Game class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Deletes Game class objects.
**************************************************************************************************************/
Game::~Game() {
    delete [] players[0].get_hand().get_cards();
    delete [] players[1].get_hand().get_cards(); 
}

/**************************************************************************************************************
 ** Function: get_player
 ** Description: Gives you the value of a player in the players variable in the Game class.
 ** Parameters: int n
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: Returns a player from the players variable.
**************************************************************************************************************/
Player Game::get_player(int n) {
    return players[n];
}

/**************************************************************************************************************
 ** Function: playable
 ** Description: Tells you if the player has any options left.
 ** Parameters: int n
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: Returns a bool indicating whether or not the player can play or draw a card.
**************************************************************************************************************/
bool Game::playable(int n) {
    for (int x = 0; x < players[n].get_hand().get_n_cards_hand(); x++)
        if (players[n].get_hand().get_card_hand(x).get_rank() == cards.get_top_card().get_rank() || 
            players[n].get_hand().get_card_hand(x).get_suit() == cards.get_top_card().get_suit() ||
            players[n].get_hand().get_card_hand(x).get_rank() == 7)
            return true;
    
    if (cards.get_n_cards() == 0)
        return false;
    
    return true;
}

/**************************************************************************************************************
 ** Function: get_int
 ** Description: Tells you if the input is an int.
 ** Parameters: string message
 ** Pre-Conditions: 1 string
 ** Post-Conditions: Returns the converted string input as an int.
**************************************************************************************************************/
int Game::get_int(string message) {
    bool valid = false;
    string choice = "";

    while (!valid) {
        valid = true;
        getline(cin, choice);

        for (int x = 0; x < choice.length(); x++)
            if (choice[x] < '0' || choice[x] > '9')
                valid = false;

        if (!valid)
            cout << "Error: ints only. Try again.\n\n" << message;
    }

    return stoi(choice);
}

/**************************************************************************************************************
 ** Function: works
 ** Description: Tells you if the chosen card can be played.
 ** Parameters: int n, int player
 ** Pre-Conditions: 2 ints.
 ** Post-Conditions: Returns a bool indicating whether or not the chosen card can be played.
**************************************************************************************************************/
bool Game::works(int n, int player) {
    if ((players[player].get_hand().get_card_hand(n).get_rank() == cards.get_top_card().get_rank()) ||
       (players[player].get_hand().get_card_hand(n).get_suit() == cards.get_top_card().get_suit()) ||
       (players[player].get_hand().get_card_hand(n).get_rank() == 7))
        return true;
    
    return false;
}

/**************************************************************************************************************
 ** Function: valid_choice
 ** Description: The player chooses to play or draw a card.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns an int representing the player's choice of action.
**************************************************************************************************************/
int Game::valid_choice() {
    bool valid = false;
    int choice = 0;

    while (!valid) {
        if (cards.get_n_cards() > 0) {
            cout << "Enter the card you want to set down or enter 0 to draw a card: ";
            choice = get_int("Enter the card you want to set down or enter 0 to draw a card: ");
        } else if (cards.get_n_cards() == 0) {
            cout << "Enter the card you want to set down (there are no more cards left in the deck): ";
            choice = get_int("Enter the card you want to set down (there are no more cards left in the deck): ");
        }

        if (cards.get_n_cards() > 0 && choice == 0)
            valid = true;
        else if (choice >= 1 && choice <= players[0].get_hand().get_n_cards_hand())
            valid = works(choice - 1, 0);

        if (!valid)
            cout << "Error: invalid choice. Try again.\n" <<endl;
    }

    return choice;
}

/**************************************************************************************************************
 ** Function: wold_card
 ** Description: The player chooses the suit they want for the 8 card.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the new suit value for the 8 card.
**************************************************************************************************************/
int Game::wild_card() {
    int new_suit = -1;

    while (new_suit < 0 || new_suit > 3) {
        cout << "Pick a suit (0-clubs, 1-diamonds, 2-hearts, 3-spades): ";
        
        new_suit = get_int("Pick a suit (0-clubs, 1-diamonds, 2-hearts, 3-spades): ");

        if (!(new_suit >= 0 && new_suit <= 3))
            cout << "Error: invalid input. Try again.\n" <<endl;
    }

    return new_suit;
}

/**************************************************************************************************************
 ** Function: player_turn
 ** Description: The user's turn.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The user makes a choice of action.
**************************************************************************************************************/
void Game::player_turn() {
    bool valid = false;

    while (!valid && playable(0)) {
        cout << "\nTop card: " << cards.get_top_card().convert_rank(cards.get_top_card().get_rank()) << " " << cards.get_top_card().convert_suit(cards.get_top_card().get_suit()) <<endl;
        cout << "Your cards: " <<endl;
        players[0].print_hand();

        int choice = valid_choice();

        if (choice == 0) {
            players[0].set_hand(1, 0, cards);
        } else {
            cards.set_top_card(players[0].get_hand().get_card_hand(choice - 1));

            if (players[0].get_hand().get_card_hand(choice - 1).get_rank() == 7 && players[0].get_hand().get_n_cards_hand() > 1) 
                cards.set_top_card_suit(wild_card());

            players[0].set_hand(-1, choice - 1, cards);
            valid = true;
        }
    } 
}

/**************************************************************************************************************
 ** Function: computer_turn
 ** Description: The computer's turn.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The computer makes a choice of action.
**************************************************************************************************************/
void Game::computer_turn() {
    bool add = true;

    srand(time(NULL));

    while (add && playable(1)) {
        for (int x = 0; x < players[1].get_hand().get_n_cards_hand(); x++)
            if (works(x, 1)) {
                cards.set_top_card(players[1].get_hand().get_card_hand(x));

                if (players[1].get_hand().get_card_hand(x).get_rank() == 7)
                    cards.set_top_card_suit(rand() % 4);
                
                players[1].set_hand(-1, x, cards);              
                add = false;
                break;
            }
        
        if (add)
            players[1].set_hand(1, 0, cards);
    }
}

/**************************************************************************************************************
 ** Function: win
 ** Description: Tells you if any of the players won.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns a bool indicating if any of the players won.
**************************************************************************************************************/
bool Game::win() {
    if (players[0].get_hand().get_n_cards_hand() == 0) {
        cout << "\n" << players[0].get_name() << " ran out of cards, " << players[0].get_name() << " wins!" <<endl;
    } else if (players[1].get_hand().get_n_cards_hand() == 0) {
        cout << "\n" << players[1].get_name() << " ran out of cards, " << players[1].get_name() << " wins!" <<endl;
    } else if (!playable(0) || !playable(1)) {
        cout << "\nThere are no more cards left in the deck and both players are unable to play their cards." <<endl;
        cout << players[0].get_name() << " has " << players[0].get_hand().get_n_cards_hand() << " card(s) left." <<endl;
        cout << players[1].get_name() << " has " << players[1].get_hand().get_n_cards_hand() << " card(s) left." <<endl;

        if (players[0].get_hand().get_n_cards_hand() < players[1].get_hand().get_n_cards_hand())
            cout << players[0].get_name() << " wins!" <<endl;
        else if (players[0].get_hand().get_n_cards_hand() > players[1].get_hand().get_n_cards_hand())
            cout << players[1].get_name() << " wins!" <<endl;
    } else {
        return false;
    }
    
    return true;
}

/**************************************************************************************************************
 ** Function: end_game
 ** Description: The user chooses whether or not they want to end or continue playing the game.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns an int representing their decision.
**************************************************************************************************************/
int Game::end_game() {
    int game_over = -1;
    
    while (game_over != 0 && game_over != 1) {
        cout << "\nDo you want to play again (0-yes, 1-no)? ";
        
        game_over = get_int("Do you want to play again (0-yes, 1-no)? ");
        
        if (game_over != 0 && game_over != 1)
            cout << "Error: invalid input. Try again." <<endl;    
    }

    return game_over;
}
