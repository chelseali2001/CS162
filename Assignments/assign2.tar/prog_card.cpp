#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "./prog_card.h"
#include "./prog_deck.h"
#include "./prog_hand.h"
#include "./prog_player.h"
#include "./prog_game.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Card
 ** Description: Initializes objects of Card class.
 ** Parameters: int rank_val, int suit_val
 ** Pre-Conditions: 2 ints.
 ** Post-Conditions: Initializes the rank and suit variables in the Card class.
**************************************************************************************************************/
Card::Card(int rank_val, int suit_val) {
    rank = rank_val;
    suit = suit_val;
}

/**************************************************************************************************************
 ** Function: get_rank
 ** Description: Gives you the value of the rank variable in the Card class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the rank variable.
**************************************************************************************************************/
int Card::get_rank() {
    return rank;
}

/**************************************************************************************************************
 ** Function: get_suit
 ** Description: Gives you the value of the suit variable in the Card class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the suit variable.
**************************************************************************************************************/
int Card::get_suit() {
    return suit;
}

/**************************************************************************************************************
 ** Function: set_suit
 ** Description: Changes the value of the suit variable in the Card class.
 ** Parameters: int suit_val
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: The value of the suit variable is changed to a new value.
**************************************************************************************************************/
void Card::set_suit(int suit_val) {
    suit = suit_val;
}

/**************************************************************************************************************
 ** Function: convert_rank
 ** Description: Converts the value of the rank variable in the Card class to its respective representation.
 ** Parameters: int n
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: Returns the string value of the converted rank variable.
**************************************************************************************************************/
string Card::convert_rank(int n) {
    if (n >= 1 && n <= 9)
        return to_string(n + 1);
    else if (n == 0)
        return "A";
    else if (n == 10)
        return  "J";
    else if (n == 11)
        return "Q";
    else if (n == 12)
        return "K";
}

/**************************************************************************************************************
 ** Function: convert_suit
 ** Description: Converts the value of the suit variable in the Card class to its respective representation.
 ** Parameters: int n
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: Returns the string value of the converted suit variable.
**************************************************************************************************************/
string Card::convert_suit(int n) {
    if (n == 0)
        return "clubs";
    else if (n == 1)
        return "diamonds";
    else if (n == 2)
        return "hearts";
    else if (n == 3)
        return "spades";

}