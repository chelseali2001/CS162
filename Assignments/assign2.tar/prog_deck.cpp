#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "./prog_card.h"
#include "./prog_deck.h"
#include "./prog_hand.h"
#include "./prog_player.h"
#include "./prog_game.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Deck
 ** Description: Initializes objects of Deck class.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Initializes the n_cards, cards, and top_card variables in the Card class.
**************************************************************************************************************/
Deck::Deck() {
    srand(time(NULL));
    n_cards = 0;

    for (int x = 0; x < 13; x++)
        for (int i = 0; i < 4; i++) {
            cards[n_cards] = Card(x, i);
            n_cards++;
        } 

    for (int x = 0; x < 52; x++) {
        int index = x;

        while (index == x)
            index = rand() % 52;

        Card random_card = cards[index];
        cards[index] = cards[x];
        cards[x] = random_card;
    }
}

/**************************************************************************************************************
 ** Function: get_card
 ** Description: Gives you the value of the card in the cards variable in the Deck class.
 ** Parameters: int index
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: Returns a card in the cards variable.
**************************************************************************************************************/
Card Deck::get_card(int index) {
    return cards[index];
}

/**************************************************************************************************************
 ** Function: get_n_cards
 ** Description: Gives you the value of the n_cards variable in the Deck class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the n_cards variable.
**************************************************************************************************************/
int Deck::get_n_cards() {
    return n_cards;
}

/**************************************************************************************************************
 ** Function: get_top_card
 ** Description: Gives you the value of the top_card variable in the Deck class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the top_card variable.
**************************************************************************************************************/
Card Deck::get_top_card() {
    return top_card;
}

/**************************************************************************************************************
 ** Function: set_top_card
 ** Description: Changes the value of the top_card variable in the Deck class.
 ** Parameters: Card card
 ** Pre-Conditions: 1 Card.
 ** Post-Conditions: The value of the top_card variable is changed to a new value.
**************************************************************************************************************/
void Deck::set_top_card(Card card) {
    top_card = card;
}

/**************************************************************************************************************
 ** Function: set_top_card_suit
 ** Description: Changes the value of the rank for the top_card variable in the Deck class.
 ** Parameters: int n
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: The value of rank for the top_card variable is changed to a new value.
**************************************************************************************************************/
void Deck::set_top_card_suit(int n) {
    top_card.set_suit(n);
}

/**************************************************************************************************************
 ** Function: reduce_n_cards_deck
 ** Description: Reduces the value of the n_cards variable in the Deck class by 1.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The value of the n_cards is reduced by 1.
**************************************************************************************************************/
void Deck::reduce_n_cards_deck() {
    n_cards--;
}
