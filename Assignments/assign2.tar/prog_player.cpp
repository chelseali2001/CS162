#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "./prog_card.h"
#include "./prog_deck.h"
#include "./prog_hand.h"
#include "./prog_player.h"
#include "./prog_game.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Player
 ** Description: Initializes objects of Player class.
 ** Parameters: string player_name, Deck& cards
 ** Pre-Conditions: 1 string and 1 Deck&
 ** Post-Conditions: Initializes the hand and name variables in the Player class.
**************************************************************************************************************/
Player::Player(string player_name, Deck& cards) {
    hand = Hand(cards);
    name = player_name;
}

/**************************************************************************************************************
 ** Function: get_hand
 ** Description: Gives you the value of the hand variable in the Player class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the hand variable.
**************************************************************************************************************/
Hand Player::get_hand() {
    return hand;
}

/**************************************************************************************************************
 ** Function: get_name
 ** Description: Gives you the value of the name variable in the Player class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the name variable.
**************************************************************************************************************/
string Player::get_name() {
    return name;
}

/**************************************************************************************************************
 ** Function: set_hand
 ** Description: Adds or removes a card from the player's hand.
 ** Parameters: int n, int index, Deck& cards
 ** Pre-Conditions: 2 ints and 1 Deck&.
 ** Post-Conditions: A card is added or removed from the player's hand.
**************************************************************************************************************/
void Player::set_hand(int n, int index, Deck& cards) {
    if (n == 1)
        hand.add_cards(cards);
    else if (n == -1)
        hand.remove_cards(index, cards);
}

/**************************************************************************************************************
 ** Function: print_hand
 ** Description: Prints the value of the cards in the player's hand.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The cards in the player's hand is printed.
**************************************************************************************************************/
void Player::print_hand() {
    for (int x = 0; x < hand.get_n_cards_hand(); x++) {
        Card current_card = hand.get_card_hand(x);
        cout << x + 1 << ". " << current_card.convert_rank(current_card.get_rank()) << " of " << current_card.convert_suit(current_card.get_suit()) <<endl;
    }

    cout <<endl;
}