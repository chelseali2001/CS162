#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

class Hand {
    private:
        Card* cards;
        int n_cards;  // Number of cards in the hand.
    public:
        Hand(){};
        Hand(Deck&);
        Card get_card_hand(int);
        Card* get_cards();
        int get_n_cards_hand();
        void add_cards(Deck&);
        void remove_cards(int, Deck&);
};