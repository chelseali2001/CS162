#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

class Deck {
    private:
        Card cards[52];
        int n_cards;  // Number of cards remaining in the deck.
        Card top_card;
    public:
        Deck();
        Card get_card(int);
        int get_n_cards();
        Card get_top_card();
        void reduce_n_cards_deck();
        void set_top_card(Card);
        void set_top_card_suit(int);
};