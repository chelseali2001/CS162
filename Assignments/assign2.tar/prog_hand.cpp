#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "./prog_card.h"
#include "./prog_deck.h"
#include "./prog_hand.h"
#include "./prog_player.h"
#include "./prog_game.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Hand
 ** Description: Initializes objects of Hand class.
 ** Parameters: Deck& card_deck
 ** Pre-Conditions: 1 Deck&.
 ** Post-Conditions: Initializes the cards and n_cards variable in Hand class.
**************************************************************************************************************/
Hand::Hand(Deck& card_deck) {
    n_cards = 7;
    cards = new Card[7];

    for (int x = 0; x < 7; x++) {
        int index = 52 - card_deck.get_n_cards();
        cards[x] = card_deck.get_card(index);
        card_deck.reduce_n_cards_deck();
    }
}

/**************************************************************************************************************
 ** Function: get_card_hand
 ** Description: Gives you the value of a card in the cards variable in the Hand class.
 ** Parameters: int index
 ** Pre-Conditions: 1 int.
 ** Post-Conditions: Returns the value of a card in the cards variable.
**************************************************************************************************************/
Card Hand::get_card_hand(int index) {
    return cards[index];
}

/**************************************************************************************************************
 ** Function: get_cards
 ** Description: Gives you the cards variable in the Hand class.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Returns the cards variable.
**************************************************************************************************************/
Card* Hand::get_cards() {
    return cards;
}

/**************************************************************************************************************
 ** Function: get_n_cards_hand
 ** Description: Gives you the value of n_cards variable in the Hand class.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Returns the value of the n_cards variable.
**************************************************************************************************************/
int Hand::get_n_cards_hand() {
    return n_cards;
}

/**************************************************************************************************************
 ** Function: add_cards
 ** Description: Adds a card to the player's hand.
 ** Parameters: Deck& card_deck
 ** Pre-Conditions: 1 Deck&
 ** Post-Conditions: A card is added to the player's hand.
**************************************************************************************************************/
void Hand::add_cards(Deck& card_deck) {
    Card* old_cards = cards;
    cards = new Card[n_cards + 1];

    for (int x = 0; x < n_cards; x++)
        cards[x] = old_cards[x];
    
    int index = 52 - card_deck.get_n_cards();
    cards[n_cards] = card_deck.get_card(index);
    card_deck.reduce_n_cards_deck();
    n_cards++;
    
    delete [] old_cards;
}

/**************************************************************************************************************
 ** Function: remove_cards
 ** Description: Removes a card from the player's hand.
 ** Parameters: int n, Deck& card_deck
 ** Pre-Conditions: 1 int and 1 Deck&.
 ** Post-Conditions: A card is removed from the player's hand.
**************************************************************************************************************/
void Hand::remove_cards(int n, Deck& card_deck) {
    Card* old_cards = cards;
    cards = new Card[n_cards - 1];
    n_cards--;

    for (int x = 0; x < n; x++)
        cards[x] = old_cards[x];
    
    for (int x = n; x < n_cards; x++)
        cards[x] = old_cards[x + 1];
    
    delete [] old_cards;
}
