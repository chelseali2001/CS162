/******************************************************
** Program: crazyeights.cpp
** Author: Chelsea Li
** Date: 4/26/20
** Description: Crazy Eights!
** Input: ints
** Output: Simulation of the game of Crazy Eights!
******************************************************/

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include "./prog_card.h"
#include "./prog_deck.h"
#include "./prog_hand.h"
#include "./prog_player.h"
#include "./prog_game.h"

using namespace std;

int main() {
    int game_over = 0;

    while (game_over == 0) {
        int turn = 0, done = 0;
        Game game;

        while (!game.win()) { //Alternating between players
            if (turn % 2 == 0)
                game.player_turn();
            else if (turn % 2 != 0)
                game.computer_turn();
            
            turn++;
        }

        game_over = game.end_game(); //User decides if they want to end the game
    }

    return 0;
}