#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

class Game {
    private:
        Deck cards;
        Player players[2];
    public:
        Game();
        ~Game();
        Player get_player(int);
        bool playable(int);
        int get_int(string);
        bool works(int, int);
        int valid_choice();
        int wild_card();
        void player_turn();  
        void computer_turn();
        bool win(); 
        int end_game();
};