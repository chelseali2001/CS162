#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdexcept>
#include "./Linked_List.hpp"

#ifndef OTHER_H
#define OTHER_H

using namespace std;

int int_or_unsigned();
unsigned int enter_num_int(Linked_List<int>&, int);
unsigned int more_nums_int(Linked_List<int>&);
unsigned int enter_num_unsigned(Linked_List<unsigned int>&, int);
unsigned int more_nums_unsigned(Linked_List<unsigned int>&);
string choose_mode();
string start_over();
void int_list();
void unsigned_list();

#endif