#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdexcept>
#include "./Node.hpp"

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

using namespace std;

template <class T>
class Linked_List {
    private:
        unsigned int length;
        Node<T> *head; 

    public:
        Linked_List();
        ~Linked_List();
        int get_length();
        Node<T>** get_head();
        bool check_primes(T);
        void print();
        void clear();
        unsigned int push_front(T);
        unsigned int push_back(T);
        unsigned int insert(T, unsigned int);
        void split(Node<T>*, Node<T>**, Node<T>**);
        void merge_sort(Node<T>**);
        void sort_ascending(Node<T>**, Node<T>*, Node<T>*);
        void sort_descending(Node<T>**);
        void swap(Node<T>**, Node<T>*, Node<T>*, Node<T>*);
};

/**************************************************************************************************************
 ** Function: Linked_List
 ** Description: Default constructor for the Linked_List class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Initializes the member variables in the Linked_List class.
**************************************************************************************************************/
template <class T>
Linked_List<T>::Linked_List() {
    length = 0;
    head = NULL;
}

/**************************************************************************************************************
 ** Function: Linked_List
 ** Description: Destructor for the Linked_List class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Deletes all dynamically allocated memory in the Linked_List class.
**************************************************************************************************************/
template <class T>
Linked_List<T>::~Linked_List() {
    delete head;
    head = NULL;
}

/**************************************************************************************************************
 ** Function: get_length
 ** Description: Gives you the value of the length variable in the Linked_List class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the length variable.
**************************************************************************************************************/
template <class T>
int Linked_List<T>::get_length() {
    return length;
}

/**************************************************************************************************************
 ** Function: get_head
 ** Description: Gives you the value of the head variable in the Linked_List class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the head variable.
**************************************************************************************************************/
template <class T>
Node<T>** Linked_List<T>::get_head() {
    return &head;
}

/**************************************************************************************************************
 ** Function: check_primes
 ** Description: Recursivly determines if a number is prime.
 ** Parameters: T num
 ** Pre-Conditions: 1 template variable.
 ** Post-Conditions: Returns a bool indicating if the number is prime.
**************************************************************************************************************/
template <class T>
bool Linked_List<T>::check_primes(T num) {
    if (num < 2)
        return false;
    else if (num == 2 || num == 3)
        return true;
    else 
        if ((num + 1) % 6 == 0 || (num - 1) % 6 == 0)
            return true;
        else
            return false;
}

/**************************************************************************************************************
 ** Function: print
 ** Description: Prints out the values in the linked list.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: The values in the linked list are printed.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::print() {
    int primes = 0;
    Node<T>* other_head = head;

    cout << "Your linked list is: ";

    while (other_head != NULL) { 
        if (check_primes(other_head->val))
            primes++;

        cout << other_head->val << " "; 
        other_head = other_head->next; 
    } 

    cout << "\nYou have " << primes << " prime number(s) in your list." <<endl;
}

/**************************************************************************************************************
 ** Function: clear
 ** Description: Clears the values in the linked list.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: The linked list is empty.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::clear() {
    Node<T>* current_node = head;
    
    while (current_node) {
        head = current_node->next;
        delete current_node;
        current_node = head;
    }
}

/**************************************************************************************************************
 ** Function: push_front
 ** Description: Adds a new node to the front of the linked list.
 ** Parameters: T n
 ** Pre-Conditions: 1 template variable
 ** Post-Conditions: A new value is added to the front of the linked list.
**************************************************************************************************************/
template <class T>
unsigned int Linked_List<T>::push_front(T n) {
    Node<T>* new_node = new Node<T>;
    new_node->val = n;
    new_node->next = head;
    head = new_node;
    
    length++;

    return length;
}

/**************************************************************************************************************
 ** Function: push_back
 ** Description: Adds a new node to the back of the linked list.
 ** Parameters: T n
 ** Pre-Conditions: 1 template variable
 ** Post-Conditions: A new value is added to the back of the linked list.
**************************************************************************************************************/
template <class T>
unsigned int Linked_List<T>::push_back(T n) {
    Node<T>* new_node = new Node<T>; 
    Node<T>* last_node = head;
      
    new_node->val = n;  
    new_node->next = NULL;  

    if (head == NULL)  {  
        head = new_node;
    } else {
        while (last_node->next != NULL)  
            last_node = last_node->next;  
        
        last_node->next = new_node;  
    }
    
    length++;
    
    return length; 
}

/**************************************************************************************************************
 ** Function: insert
 ** Description: Adds a new node to the linked list.
 ** Parameters: T val, unsigned int index
 ** Pre-Conditions: 1 template variable and 1 unsigned int
 ** Post-Conditions: A new value is added to the linked list.
**************************************************************************************************************/
template <class T>
unsigned int Linked_List<T>::insert(T val, unsigned int index) {
    if (index < 0 || index > length) {
        cout << "Error: index out of bounds" <<endl;
    } else if (index == 0)  {
        length = push_front(val);
    } else if (index == length) {
        length = push_back(val);
    } else {
        Node<T>* current = head;
        Node<T>* new_node = new Node<T>;

        new_node->val = val;
        new_node->next = NULL;

        while (index-- > 1) 
            current = current->next; 

        new_node->next = current->next; 
        current->next = new_node; 
        
        length++;
    }

    return length;
}

/**************************************************************************************************************
 ** Function: split
 ** Description: Splits the linked list in half.
 ** Parameters: Node<T>* current, Node<T>** front, Node<T>** back
 ** Pre-Conditions: 1 Node<T>* and 2 Node<T>**.
 ** Post-Conditions: The linked list is split in half.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::split(Node<T>* current, Node<T>** front, Node<T>** back) {
    Node<T>* f = current->next; 
    Node<T>* b = current; 
  
    while (f != NULL) { 
        f = f->next; 

        if (f != NULL) { 
            b = b->next; 
            f = f->next; 
        } 
    } 

    *front = current; 
    *back = b->next; 
    b->next = NULL; 
}

/**************************************************************************************************************
 ** Function: merge_sort
 ** Description: Using merge sort to sort the values in the linked list in ascending order.
 ** Parameters: Node<T>** other_head
 ** Pre-Conditions: 1 Node<T>**.
 ** Post-Conditions: A sorted list in ascending order.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::merge_sort(Node<T>** other_head) {
    Node<T>* new_head = *other_head;
    Node<T>* a;
    Node<T>* b;

    if (new_head != NULL && new_head->next != NULL) {
        split(new_head, &a, &b);
        merge_sort(&a);
        merge_sort(&b);
        sort_ascending(other_head, a, b);
    }
}

/**************************************************************************************************************
 ** Function: sort_acending
 ** Description: Sorts the values in ascending order.
 ** Parameters: Node<T>** other_head, Node<T>* a, Node<T>* b
 ** Pre-Conditions: 1 Node<T>** and 2 Node<T>*.
 ** Post-Conditions: The values are sorted in ascending order.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::sort_ascending(Node<T>** other_head, Node<T>* a, Node<T>* b) {
    if (a == NULL) {
        *other_head = b;
    } else if (b == NULL) {
        *other_head = a;
    } else {
        if (a->val <= b->val) {
            *other_head = a;
            sort_ascending(&(*other_head)->next, a->next, b);
        } else {
            *other_head = b;
            sort_ascending(&(*other_head)->next, a, b->next);
        }
    }
}

/**************************************************************************************************************
 ** Function: sort_descending
 ** Description: Sorts the values in the linked list in descending order.
 ** Parameters: Node<T>** other_head
 ** Pre-Conditions: 1 Node<T>**.
 ** Post-Conditions: The values in the linked list is sorted in descending order.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::sort_descending(Node<T>** other_head) {
    if ((*other_head) != NULL) {
        if ((*other_head)->next != NULL) {
            Node<T>* max = *other_head;
            Node<T>* prevMax = NULL;
            Node<T>* ptr = *other_head;
            
            while (ptr->next != NULL) {
                if (ptr->next->val > max->val) {
                    max = ptr->next;
                    prevMax = ptr;
                }
                
                ptr = ptr->next;
            }
            
            if (max != *other_head)
                swap(other_head, *other_head, max, prevMax);
            
            sort_descending(&(*other_head)->next);
        }
    }
}

/**************************************************************************************************************
 ** Function: swap
 ** Description: Values are swapped
 ** Parameters: Node<T>** other_head_ref, Node<T>* other_head, Node<T>* max, Node<T>* prevMax
 ** Pre-Conditions: 1 Node<T>** and 3 Node<T>*.
 ** Post-Conditions: Values are swapped.
**************************************************************************************************************/
template <class T>
void Linked_List<T>::swap(Node<T>** other_head_ref, Node<T>* other_head, Node<T>* max, Node<T>* prevMax) {
    *other_head_ref = max;
    prevMax->next = other_head;
    
    Node<T>* temp = max->next;
    max->next = other_head->next;
    other_head->next = temp;
}

#endif