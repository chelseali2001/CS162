#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdexcept>
#include "./Other.hpp"

using namespace std;

/******************************************************
** Program: linked_list.cpp
** Author: Chelsea Li
** Date: 5/24/20
** Description: Sorting linked lists
** Input: None
** Output: Sorted linked lists
******************************************************/
int main() {
    string end = "y";
    
	while (end == "y") {
        int option = int_or_unsigned();

        if (option == 1)
            int_list();
        else if (option == 2)
            unsigned_list();

        end = start_over();
    }    

    return 0;
}