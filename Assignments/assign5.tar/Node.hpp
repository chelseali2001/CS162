#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdexcept>

#ifndef NODE_H
#define NODE_H

using namespace std;

template <class T>
class Node {
    public:
        T val;
        Node<T> *next;
};

#endif