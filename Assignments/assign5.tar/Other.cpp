#include <iostream>
#include <string>
#include <stdlib.h>
#include <stdexcept>
#include "./Linked_List.hpp"
#include "./Other.hpp"

using namespace std;

/**************************************************************************************************************
 ** Function: int_or_unsigned
 ** Description: User decides if they want to enter ints or unsigned ints.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns an int indicating what datatype the user wants to use.
**************************************************************************************************************/
int int_or_unsigned() {
    int choice = 0;

    while (choice != 1 && choice != 2) {
        cout << "Enter 1 to enter ints or 2 to enter unsigned ints: ";
        cin >> choice;

        if (choice != 1 && choice != 2) {
            cin.clear();
            cin.ignore(256, '\n');
            cout << "Error: enter 1 or 2.\n" <<endl;
        }
    }

    return choice;
}

/**************************************************************************************************************
 ** Function: enter_num_int
 ** Description: User enters an int to add to the linked list.
 ** Parameters: Linked_List<int> &list, int index
 ** Pre-Conditions: 1 Linked_List<int>& and 1 int.
 ** Post-Conditions: Returns the new list length.
**************************************************************************************************************/
unsigned int enter_num_int(Linked_List<int> &list, int index) {
    bool valid_num = false;
    string num = "";

    while (!valid_num) {
        cout << "Enter a number: ";
    
        try {
            cin >> num;
    
            for (int x = 0; x < num.length(); x++)
                if (num[x] == '-' && x == 0)
                    continue;
                else if (num[x] < '0' || num[x] > '9')
                    throw invalid_argument("Error: ints only.\n");
            
            stoi(num);
            valid_num = true;
        } catch (const invalid_argument& ia) {
            cout << ia.what() <<endl;
        } catch (out_of_range const&) {
            cout << "Error: out of range.\n" <<endl;
        }
    }

    return list.insert(stoi(num), index);
}

/**************************************************************************************************************
 ** Function: more_nums_int
 ** Description: User enters chooses to add more numbers to the linked list.
 ** Parameters: Linked_List<int> &list
 ** Pre-Conditions: 1 Linked_List<int>&.
 ** Post-Conditions: Returns the new list length.
**************************************************************************************************************/
unsigned int more_nums_int(Linked_List<int> &list) {
    bool valid = false;
    int length = 0;
    string num = "", add = "";

    while (!valid) {
        cout << "Do you want another num (y or n): ";
        cin >> add;

        if (add == "y")
            length = enter_num_int(list, list.get_length());
        else if (add != "y" && add != "n")
            cout << "Error: enter y or n.\n" <<endl;
        else if (add == "n")
            valid = true;
    }

    return length;
}

/**************************************************************************************************************
 ** Function: enter_num_unsigned
 ** Description: User enters an unsigned int to add to the linked list.
 ** Parameters: Linked_List<int> &list, int index
 ** Pre-Conditions: 1 Linked_List<int>& and 1 int.
 ** Post-Conditions: Returns the new list length.
**************************************************************************************************************/
unsigned int enter_num_unsigned(Linked_List<unsigned int> &list, int index) {
    bool valid_num = false;
    string num = "";

    while (!valid_num) {
        cout << "Enter a number: ";
        
        try {
            cin >> num;

            for (int x = 0; x < num.length(); x++)    
                if (num[x] < '0' || num[x] > '9')
                    throw invalid_argument("Error: unsigned ints only.\n");
            
            stoul(num);
            valid_num = true;
        } catch (const invalid_argument& ia) {
            cout << ia.what() <<endl;
        } catch (out_of_range const&) {
            cout << "Error: out of range.\n" <<endl;
        }
    }

    return list.insert(stoul(num), index);
}

/**************************************************************************************************************
 ** Function: more_nums_unsigned
 ** Description: User enters chooses to add more numbers to the linked list.
 ** Parameters: Linked_List<int> &list
 ** Pre-Conditions: 1 Linked_List<int>&.
 ** Post-Conditions: Returns the new list length.
**************************************************************************************************************/
unsigned int more_nums_unsigned(Linked_List<unsigned int> &list) {
    bool valid = false;
    int length = 0;
    string num = "", add = "";

    while (!valid) {
        cout << "Do you want another num (y or n): ";
        cin >> add;

        if (add == "y")
            length = enter_num_unsigned(list, list.get_length());
        else if (add != "y" && add != "n")
            cout << "Error: enter y or n.\n" <<endl;
        else if (add == "n")
            valid = true;
    }

    return length;
}

/**************************************************************************************************************
 ** Function: choose_mode
 ** Description: User enters chooses the sorting mode they want.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns sorting mode the user chooses.
**************************************************************************************************************/
string choose_mode() {
    string sort_mode = "";

    while (sort_mode != "a" && sort_mode != "d") {
        cout << "Sort acending or descending (a or d)? ";
        cin >> sort_mode;

        if (sort_mode != "a" && sort_mode != "d")
            cout << "Error: enter a or d.\n" <<endl; 
    }

    return sort_mode;
}

/**************************************************************************************************************
 ** Function: start_over
 ** Description: User enters chooses to start over or end the program.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns a string indicating if the user wants to start over or end the program.
**************************************************************************************************************/
string start_over() {
    string end = "";

    while (end != "y" && end != "n") {
        cout << "Do you want to do this again (y or n)? ";
        cin >> end;

        if (end != "y" && end != "n")
            cout << "Error: enter y or n.\n" <<endl;
    }

    cout <<endl;

    return end;
}

/**************************************************************************************************************
 ** Function: int_list
 ** Description: Creates a linked list with ints.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: A linked list with ints is created.
**************************************************************************************************************/
void int_list() {
    Linked_List<int> list;

    int length = 0;
    string sort_mode = "";

    length = enter_num_int(list, 0);
    length = more_nums_int(list);
    sort_mode = choose_mode();

    if (sort_mode == "a")
        list.merge_sort(list.get_head());
    else if (sort_mode == "d")
        list.sort_descending(list.get_head());    
    
    list.print();
    list.clear();
}

/**************************************************************************************************************
 ** Function: unsigned_list
 ** Description: Creates a linked list with unsigned ints.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: A linked list with unsigned ints is created.
**************************************************************************************************************/
void unsigned_list() {
    Linked_List<unsigned int> list;

    int length = 0;
    string sort_mode = "";

    length = enter_num_unsigned(list, 0);
    length = more_nums_unsigned(list);
    sort_mode = choose_mode();

    if (sort_mode == "a")
        list.merge_sort(list.get_head());
    else if (sort_mode == "d")
        list.sort_descending(list.get_head());   
        
    list.print();
    list.clear();
}