Chelsea Li
933-294-417
CS162-012
Assignment 5
6/7/20

Description: 
My program creates a linked list that stores ints or unsigned ints (depending on the user's choice). The program then sorts the linked list in ascending order with merge sort or descending order with selection sort. Finally that program will count the total number of prime numbers in the list.

Instructions:
1. The user will first enter an int indicating if they want to enter ints or unsigned ints for the linked list.
2. The user will then enter a number they want to add to the list.
3. The user will either enter char 'y' to enter another number or 'n' to stop entering numbers.
4. The user will enter char 'a' to sort the list in ascending order or 'd' to sort in descending order.
5. The program will print out the sorted list as well as the number of prime numbers in the list.
6. Lastly, the user will enter char 'y' to create a new list or 'n' to end the program.

Limitations:
The program doesn't check if the user enters more than one string on the same line.

Extra Credit:
I converted the Linked_List and Node class to a template class so that I can use the same class to store either ints or unsigned ints. I also implemented sort_descending() using a recurive selection sort algorithm.

Works Cited:
https://www.geeksforgeeks.org/merge-sort-for-linked-list/
https://www.geeksforgeeks.org/recursive-selection-sort-singly-linked-list-swapping-node-links/