#include "./catalog.h"

/**************************************************************************************************************
 ** Function: is_int
 ** Description: Indicates if the given string is an int.
 ** Parameters: string n
 ** Pre-Conditions: 1 string
 ** Post-Conditions: Returns a bool indicating if the string is an int.
**************************************************************************************************************/
bool is_int(string n) {
    for (int x = 0; x < n.length(); x++)
        if (n[x] < '0' || n[x] > '9')
            return false;
    
    return true;
}

/**************************************************************************************************************
 ** Function: round_float
 ** Description: Rounds a float to the hundreth place.
 ** Parameters: float num
 ** Pre-Conditions: 1 float
 ** Post-Conditions: Returns a float rounded to the hundreth place.
**************************************************************************************************************/
float round_float(float num) { 
    float n = (int) (num * 100 + 0.5); 
    return (float) n / 100; 
} 

/**************************************************************************************************************
 ** Function: average_success_rate
 ** Description: Calculates the average success rate of the spells in a spellbook.
 ** Parameters: spellbook* spellbooks, int n
 ** Pre-Conditions: 1 1D spellbook struct array and 1 int
 ** Post-Conditions: Calculates the average success rate.
**************************************************************************************************************/
float average_success_rate(spellbook the_spellbook, int n) { 
    float average = 0;
    
    for (int x = 0; x < n; x++)
        average += the_spellbook.s[x].success_rate;
    
    average /= the_spellbook.num_spells;
    return round_float(average);
}

/**************************************************************************************************************
 ** Function: bad
 ** Description: Indicates if there's a poison or death spell in a spellbook.
 ** Parameters: spellbook* spellbooks, int index
 ** Pre-Conditions: 1 1D spellbook struct array and 1 int
 ** Post-Conditions: Returns a bool indicating if there's a poison or death spell in a spellbook.
**************************************************************************************************************/
bool bad(spellbook* spellbooks, int index) {
    for (int x = 0; x < spellbooks[index].num_spells; x++)
        if (spellbooks[index].s[x].effect == "poison" || spellbooks[index].s[x].effect == "death")
            return true;

    return false;
}

/**************************************************************************************************************
 ** Function: check_comm_line
 ** Description: Checks if the right files are provided.
 ** Parameters: int argc, char* argv[]
 ** Pre-Conditions: 1 int and 1 char**
 ** Post-Conditions: Returns a bool indicating if two existing files are provided.
**************************************************************************************************************/
bool check_comm_line(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Two files need to be provided." <<endl;
    } else if (argc > 3) {
        cout << "Only two files can be provided." <<endl;
    } else if (argc == 3) {
        ifstream in_stream1(argv[1]);
        ifstream in_stream2(argv[2]);
        
        if (in_stream1 && !in_stream2)
            cout << argv[2] << " doesn't exist." <<endl;
        else if (!in_stream1 && in_stream2)
            cout << argv[1] << " doesn't exist." <<endl;
        else if (!in_stream1 && !in_stream2)
            cout << "Both of these files don't exist." <<endl;
        else
            return true;
    }
    
    return false; 
}

/**************************************************************************************************************
 ** Function: sort_pages
 ** Description: Sorts the list of spellbooks according to number of pages.
 ** Parameters: spellbook* spellbooks, int n
 ** Pre-Conditions: 1 1D spellbook struct array and 1 int
 ** Post-Conditions: Sorts the list of spellbooks according to number of pages in accending order.
**************************************************************************************************************/
void sort_pages(spellbook* spellbooks, int n) {
    for (int x = 0; x < n; x++) 
        for (int i = x; i < n; i++) 
            if (spellbooks[i].num_pages < spellbooks[x].num_pages) {
                spellbook temp = spellbooks[x];
                spellbooks[x] = spellbooks[i];
                spellbooks[i] = temp;
            }
}

/**************************************************************************************************************
 ** Function: spell_values
 ** Description: Collects all of spells and gives the effects of the spells a value.
 ** Parameters: spellbook* spellbooks, spell* spells, int* spell_val, int n
 ** Pre-Conditions: 1 1D spellbook struct array, 1 1D spell struct array, 1 1D int array, and 1 int
 ** Post-Conditions: Changes the values of an object in the 2D array treasure object.
**************************************************************************************************************/
void spell_values(spellbook* spellbooks, spell* spells, int* spell_val, int n) {
    int index = 0;

    for (int x = 0; x < n; x++)
        for (int i = 0; i < spellbooks[x].num_spells; i++) {
            spells[index] = spellbooks[x].s[i];
            
            if (spells[index].effect == "bubble") {
                spell_val[index] = 1;
            } else if (spells[index].effect == "memory_loss") {
                spell_val[index] = 2;
            } else if (spells[index].effect == "fire") {
                spell_val[index] = 3;
            } else if (spells[index].effect == "poison") {
                spell_val[index] = 4;
            } else if (spells[index].effect == "death") {
                spell_val[index] = 5;
            }
            
            index++;
        }
    
    cout <<endl;
}

/**************************************************************************************************************
 ** Function: sort_effect
 ** Description: Sorts the spells by their effects.
 ** Parameters: spell* spells, int* spell_val, int n
 ** Pre-Conditions: 1 1D spell struct array, 1 1D int array, and 1 int
 ** Post-Conditions: Sorts the spells by their effects (bubbles, memory_loss, fire, poison, then death).
**************************************************************************************************************/
void sort_effect(spell* spells, int* spell_val, int n) {
    for (int x = 0; x < n; x++) 
        for (int i = x; i < n; i++) 
            if (spell_val[i] < spell_val[x]) {
                int num_temp = spell_val[x];
                spell_val[x] = spell_val[i];
                spell_val[i] = num_temp;

                spell temp = spells[x];
                spells[x] = spells[i];
                spells[i] = temp;
            }
}

/**************************************************************************************************************
 ** Function: sort_success
 ** Description: Sorts the spellbooks by average success rate.
 ** Parameters: spellbook* spellbooks, int n
 ** Pre-Conditions: 1 1D spellbook struct array and 1 int
 ** Post-Conditions: Sorts the spellbooks by avereage success rate in ascending order.
**************************************************************************************************************/
void sort_success(spellbook* spellbooks, int n) {
    for (int x = 0; x < n; x++) 
        for (int i = x; i < n; i++) 
            if (spellbooks[i].avg_success_rate < spellbooks[x].avg_success_rate) {
                spellbook temp = spellbooks[x];
                spellbooks[x] = spellbooks[i];
                spellbooks[i] = temp;
            }
}

/*********************************************************************************************************************
 ** Function: choice_1
 ** Description: Prints out the sorted spellbooks. Students can't see the spellbooks with a poison or death spell.
 ** Parameters: string position, spellbook* spellbooks, chosen_wizard wiz
 ** Pre-Conditions: 1 string, 1 1D spellbook struct array, 1 chosen_wizard struct
 ** Post-Conditions: Prints out the spellbooks by number of pages.
*********************************************************************************************************************/
void choice_1(string position, spellbook* spellbooks, chosen_wizard wiz) {
    sort_pages(spellbooks, wiz.spellbooks_size);
    ofstream out_stream;

    if (wiz.display == 2) {
        string filename = "";
        
        cout << "Please provide desired filename: ";
        cin >> filename;
        
        out_stream.open(filename.c_str(), ios::app);
    }
    
    for (int x = 0; x < wiz.spellbooks_size; x++) {
        bool poison_death = bad(spellbooks, x);

        if (!poison_death || (poison_death && position != "Student"))
            if (wiz.display == 1)
                cout << spellbooks[x].title << " " << spellbooks[x].num_pages <<endl;                              
            else if (wiz.display == 2)
                out_stream << spellbooks[x].title << " " << spellbooks[x].num_pages <<endl;
    }
    
    if (wiz.display == 2) {
        out_stream.close();
        cout << "Appended requested information to file" <<endl;
    }
} 

/****************************************************************************************************************
 ** Function: choice_2
 ** Description: Prints out the sorted spells. Students can't see poison or death spells.
 ** Parameters: string position, spell* spells, chosen_wizard wiz
 ** Pre-Conditions: 1 string, 1 1D spell struct array, 1 chosen_wizard struct
 ** Post-Conditions: Prints out the spells by effect.
****************************************************************************************************************/
void choice_2(string position, spell* spells, chosen_wizard wiz) {
    ofstream out_stream;

    if (wiz.display == 2) {
        string filename = "";
        
        cout << "Please provide desired filename: ";
        cin >> filename;
        
        out_stream.open(filename.c_str(), ios::app);
    }
    
    for (int x = 0; x < wiz.num_spells; x++)
        if (position == "Student" && (spells[x].effect == "poison" || spells[x].effect == "death"))
            continue;
        else
            if (wiz.display == 1)
                cout << spells[x].effect << " " << spells[x].name <<endl;
            else if (wiz.display == 2)
                out_stream << spells[x].effect << " " << spells[x].name <<endl;
    
    if (wiz.display == 2) {
        out_stream.close();
        cout << "Appended requested information to file" <<endl;
    }
}

/*******************************************************************************************************************
 ** Function: choice_3
 ** Description: Prints out the sorted spellbooks. Students can't see the spellbooks with a poison or death spell.
 ** Parameters: string position, spellbook* spellbooks, chosen_wizard wiz
 ** Pre-Conditions: 1 string, 1 1D spellbook struct array, 1 chosen_wizard struct
 ** Post-Conditions: Prints out the spellbooks by average success rate.
*******************************************************************************************************************/
void choice_3(string position, spellbook* spellbooks, chosen_wizard wiz) {
    sort_success(spellbooks, wiz.spellbooks_size);
    ofstream out_stream;

    if (wiz.display == 2) {
        string filename = "";
        
        cout << "Please provide desired filename: ";
        cin >> filename;
        
        out_stream.open(filename.c_str(), ios::app);
    }
    
    for (int x = 0; x < wiz.spellbooks_size; x++) {
        bool poison_death = bad(spellbooks, x);

        if (!poison_death || (poison_death && position != "Student"))
            if (wiz.display == 1)
                cout << spellbooks[x].title << " " << spellbooks[x].avg_success_rate <<endl;                              
            else if (wiz.display == 2)
                out_stream << spellbooks[x].title << " " << spellbooks[x].avg_success_rate <<endl;
    }
    
    if (wiz.display == 2) {
        out_stream.close();
        cout << "Appended requested information to file" <<endl;
    }
}

/**************************************************************************************************************
 ** Function: select_display
 ** Description: Allows the user to select the way they want to display the information.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Returns the chosen option.
**************************************************************************************************************/
void select_display(chosen_wizard& wiz) {
    cout << "How would you like the information displayed?" <<endl;
    cout << "Print to screen (Press 1)" <<endl;
    cout << "Print to file (Press 2)" <<endl;
    cin >> wiz.display;
    
    if (wiz.display < 1 || wiz.display > 2) {
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Invalid option, try again.\n" <<endl;
        select_display(wiz);
    } else {
        if (wiz.choice == 1) {
            choice_1(wiz.position, wiz.spellbooks, wiz);
        } else if (wiz.choice == 2) {
            sort_effect(wiz.spells, wiz.spell_val, wiz.num_spells);
            choice_2(wiz.position, wiz.spells, wiz);
        } else if (wiz.choice == 3) {
            choice_3(wiz.position, wiz.spellbooks, wiz);
        }
    }
}

/**************************************************************************************************************
 ** Function: select_option
 ** Description: Allows the user to select the way they want the data to be sorted.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Returns the chosen option.
**************************************************************************************************************/
int select_option(chosen_wizard& wiz) {
    cout << "\nWhich option would you like to choose?" <<endl;
    cout << "Sort spellbooks by number of pages (Press 1)" <<endl;
    cout << "Group spells by their effect (Press 2)" <<endl;
    cout << "Sort spellbooks by average success rate (Press 3)" <<endl;
    cout << "Quit (Press 4)" <<endl;
    cin >> wiz.choice;
    
    if (wiz.choice < 1 || wiz.choice > 4){
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Invalid choice, try again." <<endl;
        select_option(wiz);
    } else {
        return wiz.choice;
    }
}

/**************************************************************************************************************
 ** Function: get_spell_data
 ** Description: Collects the information on each spell from a spellbook.
 ** Parameters: spell* spells, int num_spells, ifstream& in_stream
 ** Pre-Conditions: 1 1D spell struct array, 1 int, and 1 ifstream&
 ** Post-Conditions: Records information from "spellbooks.txt" in spell struct and array.
**************************************************************************************************************/
void get_spell_data(spell* spells, int num_spells, ifstream& in_stream) {
    string word = "";

    for (int x = 0; x < num_spells; x++) {
        int num_words = 0;

        while (in_stream >> word) {
            if (num_words == 0) {
                spells[x].name = word;
            } else if (num_words == 1) {
                spells[x].success_rate = stof(word);
            } else if (num_words == 2) {
                spells[x].effect = word;
                break;
            }
            
            num_words++;
        }
    }
}

/**************************************************************************************************************
 ** Function: create_spells
 ** Description: Creates a spell array.
 ** Parameters: int n
 ** Pre-Conditions: 1 int
 ** Post-Conditions: Returns a dynamically allocated spell array.
**************************************************************************************************************/
spell* create_spells(int n) {
    return new spell[n];
}

/****************************************************************************************************************
 ** Function: spell_array
 ** Description: Creates an array of spells.
 ** Parameters: chosen_wizard& wiz
 ** Pre-Conditions: 1 chosen_wizard& struct
 ** Post-Conditions: Creates an array of spells for the wiz struct.
****************************************************************************************************************/
void spell_array(chosen_wizard& wiz) {
    int num_spells = 0;
    
    for (int x = 0; x < wiz.spellbooks_size; x++)
        num_spells += wiz.spellbooks[x].num_spells;

    wiz.spells = new spell[num_spells];
    wiz.spell_val = new int[num_spells];
    wiz.num_spells = num_spells;
    spell_values(wiz.spellbooks, wiz.spells, wiz.spell_val, wiz.spellbooks_size);
}

/**************************************************************************************************************
 ** Function: get_spellbook_data
 ** Description: Collects the information on each spellbook.
 ** Parameters: spellbook* spellbooks, int index, ifstream& in_stream
 ** Pre-Conditions: 1 1D spellbook struct array, 1 int, and 1 ifstream&
 ** Post-Conditions: Records information from "spellbooks.txt" in spellbook struct and array.
**************************************************************************************************************/
void get_spellbook_data(spellbook* spellbooks, int index, ifstream& in_stream) {
    int num_words = 0;
    string word = "";

    while (in_stream >> word) {
        if (num_words == 0) {
            spellbooks[index].title = word;
        } else if (num_words == 1) {
            spellbooks[index].author = word;
        } else if (num_words == 2) {
            spellbooks[index].num_pages = stoi(word);
        } else if (num_words == 3) {
            spellbooks[index].edition = stoi(word);
        } else if (num_words == 4) {
            spellbooks[index].num_spells = stoi(word);
            break;
        }
        
        num_words++;
    }
    
    spellbooks[index].s = create_spells(spellbooks[index].num_spells);
    get_spell_data(spellbooks[index].s, spellbooks[index].num_spells, in_stream);
    spellbooks[index].avg_success_rate = average_success_rate(spellbooks[index], spellbooks[index].num_spells);
}

/**************************************************************************************************************
 ** Function: create_spellbooks
 ** Description: Creates a spellbook array.
 ** Parameters: int n
 ** Pre-Conditions: 1 int
 ** Post-Conditions: Returns a dynamically allocated spellbook array.
**************************************************************************************************************/
spellbook* create_spellbooks(int n) {
    return new spellbook[n];
}

/****************************************************************************************************************
 ** Function: spellbooks_array
 ** Description: Creates a spellbook struct array.
 ** Parameters: chosen_wizard& wiz, char* argv
 ** Pre-Conditions: 1 chosen_wizard& struct and 1 char*
 ** Post-Conditions: Returns a spellbook struct array.
****************************************************************************************************************/
spellbook* spellbooks_array(chosen_wizard& wiz, char* argv) {
    string line = "";
    ifstream in_stream(argv);
    in_stream >> line;
    wiz.spellbooks_size = stoi(line);
    spellbook* spellbooks = create_spellbooks(wiz.spellbooks_size);

    for (int x = 0; x < wiz.spellbooks_size; x++)
        get_spellbook_data(spellbooks, x, in_stream);

    in_stream.close();
    
    return spellbooks;
}

/**************************************************************************************************************
 ** Function: get_wizard_data
 ** Description: Collects the information on each wizard.
 ** Parameters: wizard* wizards, int index, ifstream& in_stream
 ** Pre-Conditions: 1 1D wizard struct array, 1 int, and 1 ifstream&
 ** Post-Conditions: Records information from "wizard.txt" in wizard struct and array.
**************************************************************************************************************/
void get_wizard_data(wizard* wizards, int index, ifstream& in_stream) {
    int num_words = 0;
    string word = "";

    while (in_stream >> word) {
        if (num_words == 0) {
            wizards[index].name = word;
        } else if (num_words == 1) {
            wizards[index].id = stoi(word);
        } else if (num_words == 2) {
            wizards[index].password = word;
        } else if (num_words == 3) {
            wizards[index].position_title = word;
        } else if (num_words == 4) {
            wizards[index].beard_length = stof(word);
            break;
        }
    
        num_words++;
    }
}

/**************************************************************************************************************
 ** Function: create_wizards
 ** Description: Creates a wizard array.
 ** Parameters: int n
 ** Pre-Conditions: 1 int
 ** Post-Conditions: Returns a dynamically allocated wizard array.
**************************************************************************************************************/
wizard* create_wizards(int n) {
    return new wizard[n];
}

/****************************************************************************************************************
 ** Function: wizard_array
 ** Description: Creates a wizard struct array.
 ** Parameters: chosen_wizard& wiz, char* argv
 ** Pre-Conditions: 1 chosen_wizard& struct and 1 char*
 ** Post-Conditions: Returns a wizard struct array.
****************************************************************************************************************/
wizard* wizard_array(chosen_wizard& wiz, char* argv) {
    string line = "";
    ifstream in_stream(argv);
    in_stream >> line;
    wiz.wizards_size = stoi(line);
    wizard* wizards = create_wizards(wiz.wizards_size);

    for (int x = 0; x < wiz.wizards_size; x++)
        get_wizard_data(wizards, x, in_stream);
    
    in_stream.close();
    
    return wizards;
}

/****************************************************************************************************************
 ** Function: welcom_wizard
 ** Description: Prints out the information on the logged in wizard.
 ** Parameters: wizard* wizards, int wizard_login
 ** Pre-Conditions: 1 1D wizard struct array and 1 int
 ** Post-Conditions: Prints out the information on the logged in wizard.
****************************************************************************************************************/
void welcome_wizard(wizard* wizards, int wizard_login) {
    cout << "\nWelcome " << wizards[wizard_login].name <<endl;
    cout << "ID: " << wizards[wizard_login].id <<endl;
    cout << "Status: " << wizards[wizard_login].position_title <<endl;
    cout << "Beard Length: " << wizards[wizard_login].beard_length <<endl;     
}

/**************************************************************************************************************
 ** Function: enter_id
 ** Description: Checks if the user enters an int for the id.
 ** Parameters: nothing
 ** Pre-Conditions: nothing
 ** Post-Conditions: Returns the int value of the id.
**************************************************************************************************************/
int enter_id() {
    bool valid = false;
    string id = "";
    
    while (!valid) {
        cout << "Please enter your id: ";
        cin >> id;
        
        if (is_int(id)) {
            valid = true;
        } else {
            cin.clear();
            cin.ignore(256, '\n');
            cout << "The id must be an int." <<endl;
        }
    }
    
    return stoi(id);
}

/**************************************************************************************************************
 ** Function: login
 ** Description: Checks if the user enters the right login info.
 ** Parameters: wizard* wizards, int n
 ** Pre-Conditions: 1 1D wizard struct array and 1 int
 ** Post-Conditions: Returns the index of the logged in user in the wizards array.
**************************************************************************************************************/
int login(wizard* wizards, int n, chosen_wizard& wiz) {
    bool valid = false;
    int id = 0, invalid = 0;
    string password = "";

    while (!valid) {
        id = enter_id();
        
        cout << "Please enter your password: ";
        cin >> password;
    
        for (int x = 0; x < n; x++)
            if (id == wizards[x].id && password == wizards[x].password) {
                wiz.position = wizards[x].position_title;
                welcome_wizard(wizards, x);
                
                return x;       
            }     
    
        cout << "Incorrect id or password" <<endl;
        invalid++;
    
        if (invalid == 3)
            valid = true;
    }
    
    cout << "You've entered the wrong id or password too many times." <<endl;
    
    return -1;
}

/**************************************************************************************************************
 ** Function: delete_info
 ** Description: Deletes the dynamically allocated arrays.
 ** Parameters: wizard* wizards, spellbook* spellbooks
 ** Pre-Conditions: 1 1D wizard struct array and 1 1D spellbook struct array
 ** Post-Conditions: Deletes all memory that was dynamically allocated.
**************************************************************************************************************/
void delete_info(wizard** wizards, spellbook** spellbooks, int spellbooks_size) {
    delete [] *wizards;
    wizards = NULL;
    
    for (int x = 0; x < spellbooks_size; x++)
        delete [] (*spellbooks)[x].s;
    
    delete [] *spellbooks;
    spellbooks = NULL;
}