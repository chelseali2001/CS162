#include "./catalog.h"

/******************************************************
** Program: run_catalog.cpp
** Author: Chelsea Li
** Date: 4/12/20
** Description: Wizard Spellbook Catalog 
** Input: Text files
** Output: The catalogs
******************************************************/
int main(int argc, char* argv[]) {
    if (check_comm_line(argc, argv)) { //Checks if the command line is valid
        //Creating the values for chosen_wizard wiz
        chosen_wizard wiz;
        wizard* wizards = wizard_array(wiz, argv[1]);
        wiz.spellbooks = spellbooks_array(wiz, argv[2]);
        spell_array(wiz);
        
        //Logging in
        if (login(wizards, wiz.wizards_size, wiz) != -1)
            //The user picks an option until they want to quit
            while (select_option(wiz) != 4)
                select_display(wiz);

        //Deleting the dynamically allocated arrays
        delete_info(&wizards, &wiz.spellbooks, wiz.spellbooks_size);
        delete [] wiz.spells;
        delete [] wiz.spell_val;
    }
    
    return 0;
}