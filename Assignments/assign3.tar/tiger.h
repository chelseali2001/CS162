#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Tiger : public Animal {
    public:
        Tiger(bool);
};