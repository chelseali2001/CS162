#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "./animal.h"
#include "./sea_lion.h"
#include "./tiger.h"
#include "./bear.h"
#include "./zoo.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Sea_lion
 ** Description: Default constructor for the Sea_lion class.
 ** Parameters: bool bought
 ** Pre-Conditions: 1 bool.
 ** Post-Conditions: Initializes the member variables in the Sea_lion class.
**************************************************************************************************************/
Sea_lion::Sea_lion(bool bought) {
    species = "sea lion";

    if (bought) {
        age = 36;
        revenue = 120;
    } else {
        age = 0;
        revenue = 240;
    }

    cost = 800;
    babies = 1;
}