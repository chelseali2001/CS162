#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Bear : public Animal {
    public:
        Bear(bool);
};