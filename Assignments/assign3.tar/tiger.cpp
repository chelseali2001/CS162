#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "./animal.h"
#include "./sea_lion.h"
#include "./tiger.h"
#include "./bear.h"
#include "./zoo.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Tiger
 ** Description: Default constructor for the Tiger class.
 ** Parameters: bool bought
 ** Pre-Conditions: 1 bool.
 ** Post-Conditions: Initializes the member variables in the Tiger class.
**************************************************************************************************************/
Tiger::Tiger(bool bought) {
    species = "tiger";
    
    if (bought) {
        age = 36;
        revenue = 1500;
    } else {
        age = 0;
        revenue = 3000;
    }

    cost = 15000;
    babies = 3;
}