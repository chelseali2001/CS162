/******************************************************
** Program: zoo_tycoon.cpp
** Author: Chelsea Li
** Date: 5/10/20
** Description: Zoo tycoon!
** Input: ints
** Output: Simulation of a zoo tycoon game.
******************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "./animal.h"
#include "./sea_lion.h"
#include "./tiger.h"
#include "./bear.h"
#include "./zoo.h"

using namespace std;

int main() {
    srand(time(NULL));
    int done = 1;
    Zoo zoo;

    cout << "Welcome to Zoo Tycoon!" <<endl;

    while (zoo.get_balance() > 0 && done == 1) {
        cout << "\nYour current balance is: $" << zoo.get_balance() <<endl;
        zoo.print_animals();

        zoo.monthly_action();
        zoo.set_feed_type();
        
        if (zoo.get_add_sub() > 0) 
            zoo.add_animals(true, zoo);
        
        zoo.random_event(zoo);
        zoo.set_balance();
        done = zoo.end();
    }

    if (zoo.get_balance() <= 0)
        cout << "Your zoo went bankrupt. Game over :(" <<endl;

    return 0;
}