#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "./animal.h"
#include "./sea_lion.h"
#include "./tiger.h"
#include "./bear.h"
#include "./zoo.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Animal
 ** Description: Copy constructor for the Animal class.
 ** Parameters: const Animal& old_animal
 ** Pre-Conditions: 1 const Animal&
 ** Post-Conditions: Copies the member variables of one Animal object to another.
**************************************************************************************************************/
Animal::Animal(const Animal& old_animal) {
    species = old_animal.species;
    age = old_animal.age;
    cost = old_animal.cost;
    babies = old_animal.babies;
    food_cost = old_animal.food_cost;
    revenue = old_animal.revenue;
}

/**************************************************************************************************************
 ** Function: operator=
 ** Description: Assignment operator for the Animal class.
 ** Parameters: const Animal& old_animal
 ** Pre-Conditions: 1 const Animal&
 ** Post-Conditions: Assigns the member variables of one Animal object to another.
**************************************************************************************************************/
Animal& Animal::operator= (const Animal& old_animal) {
    species = old_animal.species;
    age = old_animal.age;
    cost = old_animal.cost;
    babies = old_animal.babies;
    food_cost = old_animal.food_cost;
    revenue = old_animal.revenue;
    return *this;
}

/**************************************************************************************************************
 ** Function: get_species
 ** Description: Gives you the value of the species variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the species variable.
**************************************************************************************************************/
string Animal::get_species() {
    return species;
}

/**************************************************************************************************************
 ** Function: get_age
 ** Description: Gives you the value of the age variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the age variable.
**************************************************************************************************************/
int Animal::get_age() {
    return age;
}

/**************************************************************************************************************
 ** Function: get_cost
 ** Description: Gives you the value of the cost variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the cost variable.
**************************************************************************************************************/
float Animal::get_cost() {
    return cost;
}

/**************************************************************************************************************
 ** Function: get_babies
 ** Description: Gives you the value of the babies variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the babies variable.
**************************************************************************************************************/
int Animal::get_babies() {
    return babies;
}

/**************************************************************************************************************
 ** Function: get_food_cost
 ** Description: Gives you the value of the food_cost variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the food_cost variable.
**************************************************************************************************************/
float Animal::get_food_cost() {
    return food_cost;
}

/**************************************************************************************************************
 ** Function: get_revenue
 ** Description: Gives you the value of the revenue variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: Returns the value of the revenue variable.
**************************************************************************************************************/
float Animal::get_revenue() {
    return revenue;
}

/**************************************************************************************************************
 ** Function: set_age
 ** Description: Changes the value of the age variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The value of the age variable is changed to a new value.
**************************************************************************************************************/
void Animal::set_age() {
    age++;
}

/**************************************************************************************************************
 ** Function: set_food_cost
 ** Description: Changes the value of the food_cost variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The value of the food_cost variable is changed to a new value.
**************************************************************************************************************/
void Animal::set_food_cost(int base_food) {
    if (species == "sea lion")
        food_cost = base_food;
    else if (species == "tiger")
        food_cost = 5 * base_food;
    else if (species == "black bear")
        food_cost = 3 * base_food;
}

/**************************************************************************************************************
 ** Function: set_revenue
 ** Description: Changes the value of the revenue variable in the Animal class.
 ** Parameters: None
 ** Pre-Conditions: None.
 ** Post-Conditions: The value of the revenue variable is changed to a new value.
**************************************************************************************************************/
void Animal::set_revenue() {
    revenue /= 2;
}