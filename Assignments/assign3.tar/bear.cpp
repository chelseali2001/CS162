#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "./animal.h"
#include "./sea_lion.h"
#include "./tiger.h"
#include "./bear.h"
#include "./zoo.h"

using namespace std;

/**************************************************************************************************************
 ** Function: Bear
 ** Description: Default constructor for the Bear class.
 ** Parameters: bool bought
 ** Pre-Conditions: 1 bool.
 ** Post-Conditions: Initializes the member variables in the Bear class.
**************************************************************************************************************/
Bear::Bear(bool bought) {
    species = "black bear";

    if (bought) {
        age = 36;
        revenue = 600;
    } else {
        age = 0;
        revenue = 1200;
    }

    cost = 6000;
    babies = 2;
}