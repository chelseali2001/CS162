#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Animal {
    protected:
        string species;
        int age;
        float cost;
        int babies;
        float food_cost;
        float revenue;
        int num_bought;
    
    public:
        Animal() {};
        Animal(const Animal&);
        Animal& operator= (const Animal&);
        string get_species();
        int get_age();
        float get_cost();
        int get_babies();
        float get_food_cost();
        float get_revenue();
        void set_age();
        void set_food_cost(int n);
        void set_revenue();
};
