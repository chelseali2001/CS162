#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Sea_lion : public Animal {
    public:
        Sea_lion(bool);
};