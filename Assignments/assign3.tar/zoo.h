#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class Zoo {
    private:
        Animal* animals;
        int num_animals;
        float balance;
        float base_food;
        string feed_type;
        string animal_species;
        int add_sub;
    
    public:
        Zoo();
        Zoo(const Zoo&);
        Zoo& operator= (const Zoo&);
        ~Zoo();
        float get_balance();
        int get_add_sub();
        void set_balance();
        void set_feed_type();
        int is_int();
        int animal_amount();
        void animal_choice();
        void monthly_action();
        void add_animals(bool, Zoo&);
        void remove_animal(int, Zoo&);
        void sick_animal(int, Zoo&);
        bool great_attendance();
        void random_event(Zoo&);
        void print_animals();
        int end();
};